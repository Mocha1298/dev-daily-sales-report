@extends('layout')


@section('title', 'Prambanan')
@section('prb_link', 'active')

@section('main')
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <div class="header-title">
                    <h4 class="card-title">Daily Report Pengguna Jasa</h4>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="basic" class="table table-striped mb-0" role="grid">
                        <tr>
                            {{-- <th> #</th> --}}
                            <th> Desc</th>
                            <th> Actual</th>
                            <th> Actual MTD</th>
                            <th> Monthly Target</th>
                            <th> % MTD Achv</th>
                            <th> Actual YTD</th>
                            <th> Annual Target</th>
                            <th> % YTD Achv</th>
                        </tr>
                        @php
                            for ($i = 0; $i < $count; $i++) {
                                $target_month[$i] = $target_pengguna_jasa[$i]->target_mountly;
                                $target_year[$i] = $target_pengguna_jasa[$i]->target_yearly;
                                $actual_month[$i] = $ticketing[$i]->actual_trx_month;
                                $actual_year[$i] = $ticketing[$i]->actual_trx_year;
                                if ($target_month[$i] != 0) {
                                    $percen_month[$i] = ($actual_month[$i] / $target_month[$i]) * 100;
                                } else {
                                    $percen_month[$i] = 0;
                                }
                                if ($target_year[$i] != 0) {
                                    $percen_year[$i] = ($actual_year[$i] / $target_year[$i]) * 100;
                                } else {
                                    $percen_year[$i] = 0;
                                }
                                $target_i_month[$i] = $target_income[$i]->target_mountly;
                                $target_i_year[$i] = $target_income[$i]->target_yearly;
                                $actual_i_month[$i] = $income[$i]->actual_nom_month;
                                $actual_i_year[$i] = $income[$i]->actual_nom_year;
                                if ($target_i_month[$i] != 0) {
                                    $percen_i_month[$i] = ($actual_i_month[$i] / $target_i_month[$i]) * 100;
                                } else {
                                    $percen_i_month[$i] = 0;
                                }
                                if ($target_i_year[$i] != 0) {
                                    $percen_i_year[$i] = ($actual_i_year[$i] / $target_i_year[$i]) * 100;
                                } else {
                                    $percen_i_year[$i] = 0;
                                }
                            }
                        @endphp
                        @for ($i = 0; $i < $count; $i++)
                            <tr data-node-id="{{ $ticketing[$i]->id_link }}">
                                <th>{{ $ticketing[$i]->deskripsi }}</th>
                                <td>{{ number_format($ticketing[$i]->actual_trx_date, 0, '', '.') }}
                                </td>
                                <td>{{ number_format($ticketing[$i]->actual_trx_month, 0, '', '.') }}
                                </td>
                                <td>{{ number_format($target_month[$i], 0, '', '.') }}</td>
                                <td>
                                    @if ($percen_month[$i] == null)
                                        0
                                    @else
                                        {{ number_format($percen_month[$i], 2, '.', '') }}
                                    @endif
                                </td>
                                <td>{{ number_format($ticketing[$i]->actual_trx_year, 0, '', '.') }}
                                </td>
                                <td>{{ number_format($target_year[$i], 0, '', '.') }}</td>
                                <td>
                                    @if ($percen_year[$i] == null)
                                        0
                                    @else
                                        {{ number_format($percen_year[$i], 2, '.', '') }}
                                    @endif
                                </td>
                            </tr>
                            @if ($ticketing[$i]->id_link == 1)
                                @php
                                    $x = 0;
                                @endphp
                                <tr data-node-pid="1">
                                    <th colspan="5">Detail</th>
                                    <th colspan="3" class="text-center">Total</th>
                                </tr>
                                @php
                                    $x++;
                                @endphp
                                @foreach ($detail_pj_dom as $item)
                                    <tr data-node-pid="1">
                                        <th colspan="5">
                                            {{ $item->trf_name }}
                                        </th>
                                        <td colspan="3" class="text-center">
                                            {{ number_format($item->total_trx, 0, '', '.') }}
                                        </td>
                                    </tr>
                                @endforeach
                            @elseif($ticketing[$i]->id_link == 2)
                                @php
                                    $x = 0;
                                @endphp
                                <tr data-node-pid="2">
                                    <th colspan="5">Detail</th>
                                    <th colspan="3" class="text-center">Total</th>
                                </tr>
                                @php
                                    $x++;
                                @endphp
                                @foreach ($detail_pj_asg as $item)
                                    <tr data-node-pid="2">
                                        <th colspan="5">
                                            {{ $item->trf_name }}
                                        </th>
                                        <td colspan="3" class="text-center">
                                            {{ number_format($item->total_trx, 0, '', '.') }}
                                        </td>
                                    </tr>
                                @endforeach
                            @elseif($ticketing[$i]->id_link == 3)
                                @php
                                    $x = 0;
                                @endphp
                                <tr data-node-pid="3">
                                    <th colspan="5">Detail</th>
                                    <th colspan="3" class="text-center">Total</th>
                                </tr>
                                @php
                                    $x++;
                                @endphp
                                @foreach ($detail_pj_pkt as $item)
                                    <tr data-node-pid="3">
                                        <th colspan="5">
                                            {{ $item->trf_name }}
                                        </th>
                                        <td colspan="3" class="text-center">
                                            {{ number_format($item->total_trx, 0, '', '.') }}
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        @endfor
                        @php
                            $tot_act_d = 0;
                            $tot_act_m = 0;
                            $target_m = 0;
                            $percen_m = 0;
                            $tot_act_y = 0;
                            $target_y = 0;
                            $percen_y = 0;
                            for ($i = 0; $i < $count; $i++) {
                                $tot_act_d = $tot_act_d + $ticketing[$i]->actual_trx_date;
                                $tot_act_m = $tot_act_m + $ticketing[$i]->actual_trx_month;
                                $target_m = $target_m + $target_month[$i];
                                $tot_act_y = $tot_act_y + $ticketing[$i]->actual_trx_year;
                                $target_y = $target_y + $target_year[$i];
                            }
                            $percen_m = ($tot_act_m / $target_m) * 100;
                            $percen_y = ($tot_act_y / $target_y) * 100;
                        @endphp
                        <tr>
                            <td></td>
                            <td>{{ number_format($tot_act_d, 0, '', '.') }}</td>
                            <td>{{ number_format($tot_act_m, 0, '', '.') }}</td>
                            <td>{{ number_format($target_m, 0, '', '.') }}</td>
                            <td>{{ number_format($percen_m, 2, '.', '') }}</td>
                            <td>{{ number_format($tot_act_y, 0, '', '.') }}</td>
                            <td>{{ number_format($target_y, 0, '', '.') }}</td>
                            <td>{{ number_format($percen_y, 2, '.', '') }}</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <div class="header-title">
                    <h4 class="card-title">Daily Report Income</h4>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="basic2" class="table table-striped mb-0" role="grid">
                        <thead>
                            <tr>
                                <th>Desc</th>
                                <th>Actual</th>
                                <th>Actual MTD</th>
                                <th>Monthly Target</th>
                                <th>% MTD Achv</th>
                                <th>Actual YTD</th>
                                <th>Annual Target</th>
                                <th>% YTD Achv</th>
                            </tr>
                        </thead>
                        @for ($i = 0; $i < $count; $i++)
                            <tr data-node-id="{{ $income[$i]->id_link }}">
                                <th>{{ $income[$i]->deskripsi }}</th>
                                <td>{{ number_format($income[$i]->actual_nom_date, 0, '', '.') }}</td>
                                <td>{{ number_format($income[$i]->actual_nom_month, 0, '', '.') }}</td>
                                <td>{{ number_format($target_i_month[$i], 0, '', '.') }}</td>
                                <td>
                                    @if ($percen_i_month[$i] == null)
                                        0
                                    @else
                                        {{ number_format($percen_i_month[$i], 2, '.', '') }}
                                    @endif
                                </td>
                                <td>{{ number_format($income[$i]->actual_nom_year, 0, '', '.') }}</td>
                                <td>{{ number_format($target_i_year[$i], 0, '', '.') }}</td>
                                <td>
                                    @if ($percen_i_year[$i] == null)
                                        0
                                    @else
                                        {{ number_format($percen_i_year[$i], 2, '.', '') }}
                                    @endif
                                </td>
                            </tr>
                            @if ($income[$i]->id_link == 1)
                                @php
                                    $x = 0;
                                @endphp
                                <tr data-node-id="2.{{ $x }}.1" data-node-pid="1">
                                    <th colspan="5">Detail</th>
                                    <th colspan="3" class="text-center">Total</th>
                                </tr>
                                @php
                                    $x++;
                                @endphp
                                @foreach ($detail_in_dom as $item)
                                    <tr data-node-id="2.{{ $x }}.1" data-node-pid="1">
                                        <th colspan="5">
                                            {{ $item->trf_name }}
                                        </th>
                                        <td colspan="3" class="text-center">
                                            {{ number_format($item->total_nom, 0, '', '.') }}
                                        </td>
                                    </tr>
                                @endforeach
                            @elseif($income[$i]->id_link == 2)
                                @php
                                    $x = 0;
                                @endphp
                                <tr data-node-id="2.{{ $x }}.2" data-node-pid="2">
                                    <th colspan="5">Detail</th>
                                    <th colspan="3" class="text-center">Total</th>
                                </tr>
                                @php
                                    $x++;
                                @endphp
                                @foreach ($detail_in_asg as $item)
                                    <tr data-node-id="2.{{ $x }}.2" data-node-pid="2">
                                        <th colspan="5">
                                            {{ $item->trf_name }}
                                        </th>
                                        <td colspan="3" class="text-center">
                                            {{ number_format($item->total_nom, 0, '', '.') }}
                                        </td>
                                    </tr>
                                @endforeach
                            @elseif($income[$i]->id_link == 3)
                                @php
                                    $x = 0;
                                @endphp
                                <tr data-node-id="2.{{ $x }}.3" data-node-pid="3">
                                    <th colspan="5">Detail</th>
                                    <th colspan="3" class="text-center">Total</th>
                                </tr>
                                @php
                                    $x++;
                                @endphp
                                @foreach ($detail_in_pkt as $item)
                                    <tr data-node-id="2.{{ $x }}.3" data-node-pid="3">
                                        <th colspan="5">
                                            {{ $item->trf_name }}
                                        </th>
                                        <td colspan="3" class="text-center">
                                            {{ number_format($item->total_nom, 0, '', '.') }}
                                        </td>
                                    </tr>
                                @endforeach
                            @endif
                        @endfor
                        @php
                            $data1 = 0;
                            $data2 = 0;
                            $data3 = 0;
                            $data4 = 0;
                            $data5 = 0;
                            $data6 = 0;
                            $data7 = 0;
                            for ($i = 0; $i < $count; $i++) {
                                $data1 = $data1 + $income[$i]->actual_nom_date;
                                $data2 = $data2 + $income[$i]->actual_nom_month;
                                $data3 = $data3 + $target_i_month[$i];
                                $data5 = $data5 + $income[$i]->actual_nom_year;
                                $data6 = $data6 + $target_i_year[$i];
                            }
                        @endphp
                        @for ($i = 0; $i < 1; $i++)
                            <tr data-node-id="{{ $erp[$i]->id_link }}">
                                <th>{{ $erp[$i]->deskripsi }}</th>
                                <td>{{ number_format($erp[$i]->actual_nominal_date, 0, '', '.') }}</td>
                                <td>{{ number_format($erp[$i]->actual_nominal_month, 0, '', '.') }}</td>
                                <td>{{ number_format($target_income_non[$i]->target_mountly, 0, '', '.') }}
                                </td>
                                <td>{{ number_format(($erp[$i]->actual_nominal_month / $target_income_non[$i]->target_mountly) * 100, 2, '.', '') }}
                                </td>
                                <td>{{ number_format($erp[$i]->actual_nominal_year, 0, '', '.') }}</td>
                                <td>{{ number_format($target_income_non[$i]->target_yearly, 0, '', '.') }}
                                </td>
                                <td>{{ number_format(($erp[$i]->actual_nominal_year / $target_income_non[$i]->target_yearly) * 100, 2, '.', '') }}
                                </td>
                            </tr>
                            @php
                                $x = 0;
                            @endphp
                            <tr data-node-id="{{ $erp[$i]->id_link }}.1" data-node-pid="{{ $erp[$i]->id_link }}">
                                <th colspan="5">Detail</th>
                                <th colspan="3" class="text-center">Total</th>
                            </tr>
                            @php
                                $x++;
                                $data1 = $data1 + $erp[$i]->actual_nominal_date;
                                $data2 = $data2 + $erp[$i]->actual_nominal_month;
                                $data3 = $data3 + $target_income_non[$i]->target_mountly;
                                $data4 = $data4 + ($erp[$i]->actual_nominal_month / $target_income_non[$i]->target_mountly) * 100;
                                $data5 = $data5 + $erp[$i]->actual_nominal_year;
                                $data6 = $data6 + $target_income_non[$i]->target_yearly;
                                $data7 = $data7 + ($erp[$i]->actual_nominal_year / $target_income_non[$i]->target_yearly) * 100;
                            @endphp
                            @foreach ($detail_in_not as $item)
                                <tr data-node-id="{{ $erp[$i]->id_link }}.2" data-node-pid="{{ $erp[$i]->id_link }}">
                                    <th colspan="5">
                                        {{ $item->AcDesc }}
                                    </th>
                                    <td>
                                        {{ number_format($item->actual_nominal_date, 0, '', '.') }}
                                    </td>
                                </tr>
                            @endforeach
                        @endfor
                        <tr>
                            <td></td>
                            <td>{{ number_format($data1, 0, '', '.') }}</td>
                            <td>{{ number_format($data2, 0, '', '.') }}</td>
                            <td>{{ number_format($data3, 0, '', '.') }}</td>
                            <td>{{ number_format($data4, 2, '.', '') }}</td>
                            <td>{{ number_format($data5, 0, '', '.') }}</td>
                            <td>{{ number_format($data6, 0, '', '.') }}</td>
                            <td>{{ number_format($data7, 2, '.', '') }}</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
