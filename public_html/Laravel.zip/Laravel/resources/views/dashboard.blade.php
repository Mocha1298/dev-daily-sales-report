@extends('layout')


@section('title', 'Dashboard')

@section('welcome')
    <div class="conatiner-fluid content-inner">

        <div class="row">

            <h1 class="text-light">Selamat Datang</h1>

        </div>

    </div>
@endsection
