<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
////////////////ROUTE GOLIVE////////////////////////////
Route::get('/','App\Http\Controllers\ReportController@home');
Route::get('/unit/{unit}','App\Http\Controllers\ReportController@dashboard');
Route::get('/filter/{unit}/{tgl_start}/{tgl_end}','App\Http\Controllers\ReportController@filter');
Route::get('/naikcandi/{start}/{end}','App\Http\Controllers\ReportController@naikcandi');
Route::get('/cron','App\Http\Controllers\ReportController@cron_naikcandi');
Route::get('/cron_tmii','App\Http\Controllers\ReportController@cron_tmii');
Route::get('/insert','App\Http\Controllers\ReportController@insertjson');
Route::get('/cek','App\Http\Controllers\ReportController@cek');


////////////////ROUTE DEVELEPER////////////////////////////
Route::get('/dev','App\Http\Controllers\ReportControllerDev@home');
Route::get('/dev/unit/borobudur/{start}/{end}','App\Http\Controllers\ReportControllerDev@borobudur');
Route::get('/dev/unit/prambanan/{start}/{end}','App\Http\Controllers\ReportControllerDev@prambanan');
Route::get('/dev/unit/ratuboko/{start}/{end}','App\Http\Controllers\ReportControllerDev@ratuboko');
Route::get('/dev/unit/tamanmini/{start}/{end}','App\Http\Controllers\ReportControllerDev@tamanmini');
Route::get('/dev/unit/manohara/{start}/{end}','App\Http\Controllers\ReportControllerDev@manohara');
Route::get('/dev/unit/teapen/{start}/{end}','App\Http\Controllers\ReportControllerDev@teapen');






// Route::get('/dev/','App\Http\Controllers\ReportControllerDev@home');
// Route::get('/dev/unit/{unit}','App\Http\Controllers\ReportControllerDev@dashboard');
// Route::get('/dev/filter/{unit}/{tgl_start}/{tgl_end}','App\Http\Controllers\ReportControllerDev@filter');
// Route::get('/dev/naikcandi/{start}/{end}','App\Http\Controllers\ReportControllerDev@naikcandi');
// Route::get('/dev/cron','App\Http\Controllers\ReportControllerDev@cron_naikcandi');
// Route::get('/dev/insert','App\Http\Controllers\ReportControllerDev@insertjson');

Route::get('/clear-cache', function(){
    Artisan::call('cache:clear');
    Artisan::call('cache:view');
    Artisan::call('cache:config');
});