<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use DateTime;
use DatePeriod;
use DateInterval;

class ReportController extends Controller
{
    public function home()
    {
        return view("home");
    }
    public function dashboard($unit)
    {
        // 1 == borobudur
        // 2 == prambanan
        // 3 == ratuboko

        if($unit == "borobudur"){
            $unit = 1;
        }elseif($unit == "prambanan"){
            $unit = 2;
        }elseif($unit == "ratuboko"){
            $unit = 3;
        }
        elseif($unit == "tmii"){
            $unit = 4;
        }elseif($unit == "manohara"){
            $unit = 5;
        }
        else{
            return redirect('/');
        }

        $tanggal = Carbon::yesterday();//TANGGAL KEMARIN (sak jam jam e ) radinggo

        $date = $tanggal->format('Ymd');//FORMAT TANGGAL TANPA STRIP (ERP)
        $tanggal = $tanggal->format('Y-m-d');//FORMAT TANGGAL STRIP
        $tanggal = "2023-04-23";
        $tgl_start = $tanggal;
        $tgl_end = $tanggal;

        $date2 = Carbon::now()->subDays(2)->format('Ymd');//TANGGAL H-2 FORMAT TANPA STRIP

        // BOROBUDUR
        if($unit == 1){
            // menghitung jumlah hari pada date range
            $dateStart = $tgl_start;
            $dateEnd = $tgl_end;
            
            $monthStart = date('m', strtotime($dateStart));
            $yearStart = date('Y', strtotime($dateStart));
            
            $monthEnd = date('m', strtotime($dateEnd));
            $yearEnd = date('Y', strtotime($dateEnd));
            
            $startDate = new DateTime("$yearStart-$monthStart-01");
            $endDate = new DateTime("$yearEnd-$monthEnd-".date('t', strtotime("$yearEnd-$monthEnd-01")));
            
            for ($date1 = $startDate; $date1 <= $endDate; $date1->modify('+1 day')) {
                // echo $date1->format('Y-m-d') . "<br>";
                $daterange[] = $date1->format('Y-m-d');
            }
            $count_last_date = count($daterange);
            $tgt_naik_candi_m = $count_last_date*1200;
            // menghitung hari dalam tahun
            $dateStart1 = "2023-01-01";
            $dateEnd1 = "2023-12-31";
            
            $monthStart1 = date('m', strtotime($dateStart1));
            $yearStart1 = date('Y', strtotime($dateStart1));
            
            $monthEnd1 = date('m', strtotime($dateEnd1));
            $yearEnd1 = date('Y', strtotime($dateEnd1));
            
            $startDate1 = new DateTime("$yearStart1-$monthStart1-01");
            $endDate1 = new DateTime("$yearEnd1-$monthEnd1-".date('t', strtotime("$yearEnd-$monthEnd-01")));
            
            for ($date1 = $startDate1; $date1 <= $endDate1; $date1->modify('+1 day')) {
                // echo $date1->format('Y-m-d') . "<br>";
                $daterange1[] = $date1->format('Y-m-d');
            }
            $count_last_date = count($daterange1);
            $tgt_naik_candi_y = $count_last_date*1200;

            $jml_tiket = DB::connection("mysql4")->select("
                select sum(ticket_price) as price, count(id) as sum from trx where date(schedule) between '".$tgl_start."' and '".$tgl_end."'
            ");
            $naik_candi = $jml_tiket[0]->sum;
            $price_naik_candi = $jml_tiket[0]->price;
            $mtd = DB::connection("mysql4")->select("
                select max(aa.act_trx) as act_mtd, max(bb.mtd_trx) as trx_mtd, max(cc.ytd_trx) as trx_ytd
                FROM 
                    trx t
                left join 
                    (select a.venue_name as venue, COUNT(*) as act_trx 
                    from 
                    trx a
                    where 
                    date(a.schedule) between '2023-04-25' and '2023-04-25'
                    GROUP by a.venue_name) aa on aa.venue = t.venue_name 
                left join 
                    (select b.venue_name as venue, COUNT(*) as mtd_trx 
                    from 
                    trx b
                    where 
                    DATE_FORMAT(date(b.schedule) , '%Y%m') between DATE_FORMAT('2023-04-25','%Y%m') and DATE_FORMAT('2023-04-25','%Y%m')
                    GROUP by b.venue_name) bb on bb.venue = t.venue_name 
                left join 
                    (select c.venue_name as venue, COUNT(*) as ytd_trx 
                    from 
                    trx c
                    where 
                    DATE_FORMAT(date(c.schedule) , '%Y') = DATE_FORMAT('2023-03-21','%Y')
                    GROUP by c.venue_name) cc on cc.venue = t.venue_name 
            ");
            $mtd_i = DB::connection("mysql4")->select("
                select max(aa.act_trx) as act_mtd, max(bb.mtd_trx) as trx_mtd, max(cc.ytd_trx) as trx_ytd
                FROM 
                    trx t
                left join 
                    (select a.venue_name as venue, sum(a.ticket_price) as act_trx 
                    from 
                    trx a
                    where 
                    date(a.schedule) between '2023-04-23' and '2023-04-23'
                    GROUP by a.venue_name) aa on aa.venue = t.venue_name 
                left join 
                    (select b.venue_name as venue, sum(b.ticket_price) as mtd_trx 
                    from 
                    trx b
                    where 
                    DATE_FORMAT(date(b.schedule) , '%Y%m') between DATE_FORMAT('2023-04-23','%Y%m') and DATE_FORMAT('2023-04-23','%Y%m')
                    GROUP by b.venue_name) bb on bb.venue = t.venue_name 
                left join 
                    (select c.venue_name as venue, sum(c.ticket_price) as ytd_trx 
                    from 
                    trx c
                    where 
                    DATE_FORMAT(date(c.schedule) , '%Y') = DATE_FORMAT('2023-04-23','%Y')
                    GROUP by c.venue_name) cc on cc.venue = t.venue_name 
            ");
            $naik_candi_act_i = $mtd_i[0]->act_mtd;
            $naik_candi_mtd_i = $mtd_i[0]->trx_mtd;
            $naik_candi_ytd_i = $mtd_i[0]->trx_ytd;

            $naik_candi_act = $mtd[0]->act_mtd;
            $naik_candi_mtd = $mtd[0]->trx_mtd;
            $naik_candi_ytd = $mtd[0]->trx_ytd;
            $acv_mtd = $naik_candi_act/$tgt_naik_candi_m*100;
            // naik candi
            $ticketing = DB::connection("pgsql")->select("
                        select w.id_link,TO_CHAR(('".$tanggal."')::date, 'yyyymmdd') as trx_date,w.deskripsi,case when x.total_trx > 0 then x.total_trx else 0 end as actual_trx_date,
                y.total_trx as actual_trx_month, z.total_trx as actual_trx_year
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                    union all
                    select 3 as id_link, 'Paket' as deskripsi
                )w
                left outer join
                (
                    select trx_date,id_link ,total_trx
                    from
                    (
                        (
                            select a.trx_date, 1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND a.trx_date = ('".$tanggal."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') 
                            group by a.trx_date, id_link
                        )
                        union all
                        (
                            select a.trx_date, 2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND a.trx_date = ('".$tanggal."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and trf_name not like '%Prahastiwi%') 
                            group by a.trx_date, id_link
                        )
                        union all
                        (
                            select a.trx_date, 3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND a.trx_date = ('".$tanggal."') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%') 
                            group by a.trx_date, id_link
                        )
                    )x
                )x on w.id_link = x.id_link
                left outer join
                (
                    select thbl,id_link,total_trx as total_trx
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 6 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by thbl,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 6 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') and a.ctg_id not in (4,5,6) and (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and trf_name not like '%Prahastiwi%')
                            group by thbl,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 6 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by thbl,  id_link
                        )
                    )y
                )y on w.id_link = y.id_link
                left outer join
                (
                    select tahun,id_link,total_trx as total_trx
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 6 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by tahun,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 6 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') and a.ctg_id not in (4,5,6) and (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and trf_name not like '%Prahastiwi%')
                            group by tahun,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 6 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by tahun,  id_link
                        )
                    )z
                )z on w.id_link=z.id_link"
            );
            $income = DB::connection("pgsql")->select("
                        select w.id_link,TO_CHAR(('".$tanggal."')::date, 'yyyymmdd') as trx_date,w.deskripsi,case when x.total_nom > 0 then x.total_nom else 0 end as actual_nom_date,
                y.total_nom as actual_nom_month, z.total_nom as actual_nom_year
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                    union all
                    select 3 as id_link, 'Paket' as deskripsi
                )w
                left outer join
                (
                    select trx_date,id_link,total_nom
                    from
                    (
                        (
                            select a.trx_date,
                            case when a.ctg_id in (4,5,6) then 1
                            else 2 end as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND a.trx_date = ('".$tanggal."') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                            group by a.trx_date, id_link
                        )
                        union all
                        (
                            select a.trx_date, 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND a.trx_date = ('".$tanggal."')  AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                            group by a.trx_date, id_link
                        )
                    )x
                )x 
                on w.id_link = x.id_link
                left outer join
                (
                    select thbl,id_link,total_nom
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,
                            case when a.ctg_id in (4,5,6) then 1
                            else 2 end as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                            group by thbl, id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl, 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                            group by thbl, id_link
                        )
                    )y
                )y on w.id_link = y.id_link
                left outer join
                (
                    select tahun,id_link,total_nom
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,
                            case when a.ctg_id in (4,5,6) then 1
                            else 2 end as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                            group by tahun, id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun, 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy')  AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                            group by tahun, id_link
                        )
                    )z
                )z on w.id_link=z.id_link
            ");
            $erp = DB::connection("mysql2")->select("
                            select x.id_link,'".$date."' as trx_date,x.deskripsi,COALESCE(x.actual_nominal_date,0) as actual_nominal_date,COALESCE(y.actual_nominal_month,0) as actual_nominal_month,COALESCE(z.actual_nominal_year,0) as actual_nominal_year
                from
                (
                    select 4 as id_link,DocDt,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_date from 
                        (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                    where 
                    left(AcNo,8) in ('4.02.02.') and AcNo <> '4.02.01.12' and (CAmt - DAmt) > 0
                    and DocDt = '".$date."'
                )x
                left outer join 
                (
                    select 4 as id_link,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_month from 
                        (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                    where 
                    left(AcNo,8) in ('4.02.02.') and AcNo <> '4.02.01.12' and (CAmt - DAmt) > 0
                    and left(DocDt,6) = LEFT('".$date."', 6)
                )y 
                on x.id_link = y.id_link
                left outer join 
                (
                    select 4 as id_link,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_year from 
                        (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                    where 
                    left(AcNo,8) in ('4.02.02.') and AcNo <> '4.02.01.12' and (CAmt - DAmt) > 0
                    and left(DocDt,4) = LEFT('".$date."', 4)
                )z 
                on x.id_link=z.id_link
            ");
            // DETAIL
            $detail_pj_dom = DB::connection("pgsql")->select(
                "select 1 as id_link, b.trf_name, sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 6 AND a.trx_date = ('".$tanggal."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%')
                group by b.trf_name"                                             
            );
            $detail_pj_asg = DB::connection("pgsql")->select(
                "select 2 as id_link, b.trf_name,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 6 AND a.trx_date = ('".$tanggal."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and trf_name not like '%Prahastiwi%')
                group by b.trf_name"
            );
            $detail_pj_pkt = DB::connection("pgsql")->select(
                "select 3 as id_link, b.trf_name,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 6 AND a.trx_date = ('".$tanggal."') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%') 
                group by b.trf_name "
            );
            $detail_in_dom = DB::connection("pgsql")->select(
                "select 1 as id_link, b.trf_name ,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.ctg_id in (4,5,6) and a.group_id = 6 AND a.trx_date = ('".$tanggal."') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                group by b.trf_name"                                                  
            );
            $detail_in_asg = DB::connection("pgsql")->select(
                "select 2 as id_link, b.trf_name ,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.ctg_id not in (4,5,6) and a.group_id = 6 AND a.trx_date = ('".$tanggal."') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                group by b.trf_name"           
            );
            $detail_in_pkt = DB::connection("pgsql")->select(
                "select 3 as id_link, b.trf_name,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 6 AND a.trx_date = ('".$tanggal."')  AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                group by b.trf_name"          
            );
            $detail_in_not = DB::connection("mysql2")->select(
                "select 4 as id_link,AcDesc, sum(CAmt - DAmt) as actual_nominal_date from 
                (
                    select a.DocDt AS DocDt,c.AcDesc,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                    from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo))
                    join tblcoa c on (b.AcNo = c.AcNo))
                ) vwtwcjn
                where 
                left(AcNo,8) in ('4.02.01.') and AcNo <> '4.02.01.11' and (CAmt - DAmt) > 0
                and DocDt = '".$date."' 
                group by AcDesc "										
            );
        }
        // PRAMBANAN
        if($unit == 2){
            $ticketing = DB::connection("pgsql")->select("
                select w.id_link,TO_CHAR(('".$tanggal."')::date, 'yyyymmdd') as trx_date,w.deskripsi,case when x.total_trx > 0 then x.total_trx else 0 end as actual_trx_date,
                y.total_trx as actual_trx_month, z.total_trx as actual_trx_year
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                    union all
                    select 3 as id_link, 'Paket' as deskripsi
                )w
                left outer join
                (
                    select trx_date,id_link ,total_trx
                    from
                    (
                        (
                            select a.trx_date, 1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND a.trx_date = ('".$tanggal."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') 
                            group by a.trx_date, id_link
                        )
                        union all
                        (
                            select a.trx_date, 2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND a.trx_date = ('".$tanggal."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') 
                            group by a.trx_date, id_link
                        )
                        union all
                        (
                            select a.trx_date, 3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND a.trx_date = ('".$tanggal."') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%') 
                            group by a.trx_date, id_link
                        )
                    )x
                )x on w.id_link = x.id_link
                left outer join
                (
                    select thbl,id_link,total_trx as total_trx
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 4 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by thbl,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 4 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by thbl,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 4 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by thbl,  id_link
                        )
                    )y
                )y on w.id_link = y.id_link
                left outer join
                (
                    select tahun,id_link,total_trx as total_trx
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 4 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by tahun,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 4 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by tahun,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 4 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by tahun,  id_link
                        )
                    )z
                )z on w.id_link = z.id_link"
            );
            $income = DB::connection("pgsql")->select("
                select w.id_link,TO_CHAR(('".$tanggal."')::date, 'yyyymmdd') as trx_date,w.deskripsi,case when x.total_nom > 0 then x.total_nom else 0 end as actual_nom_date,
                y.total_nom as actual_nom_month, z.total_nom as actual_nom_year
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                    union all
                    select 3 as id_link, 'Paket' as deskripsi
                )w
                left outer join
                (
                    select trx_date,id_link,total_nom
                    from
                    (
                        (
                            select a.trx_date,
                            case when a.ctg_id in (4,5,6) then 1
                            else 2 end as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND a.trx_date = ('".$tanggal."') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                            group by a.trx_date, id_link
                        )
                        union all
                        (
                            select a.trx_date, 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND a.trx_date = ('".$tanggal."')  AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                            group by a.trx_date, id_link
                        )
                    )x
                )x 
                on w.id_link = x.id_link
                left outer join
                (
                    select thbl,id_link,total_nom
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,
                            case when a.ctg_id in (4,5,6) then 1
                            else 2 end as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                            group by thbl, id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl, 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                            group by thbl, id_link
                        )
                    )y
                )y on w.id_link = y.id_link
                left outer join
                (
                    select tahun,id_link,total_nom
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,
                            case when a.ctg_id in (4,5,6) then 1
                            else 2 end as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                            group by tahun, id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun, 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy')  AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                            group by tahun, id_link
                        )
                    )z
                )z on w.id_link=z.id_link
            ");
            $erp = DB::connection("mysql2")->select("
                            select x.id_link,'".$date."' as trx_date,x.deskripsi,COALESCE(x.actual_nominal_date,0) as actual_nominal_date,COALESCE(y.actual_nominal_month,0) as actual_nominal_month,COALESCE(z.actual_nominal_year,0) as actual_nominal_year
                from
                (
                    select 4 as id_link,DocDt,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_date from 
                        (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                    where 
                    left(AcNo,8) in ('4.02.02.') and AcNo <> '4.02.01.12' and (CAmt - DAmt) > 0
                    and DocDt = '".$date."'
                )x
                left outer join 
                (
                    select 4 as id_link,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_month from 
                        (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                    where 
                    left(AcNo,8) in ('4.02.02.') and AcNo <> '4.02.01.12' and (CAmt - DAmt) > 0
                    and left(DocDt,6) = LEFT('".$date."', 6)
                )y 
                on x.id_link = y.id_link
                left outer join 
                (
                    select 4 as id_link,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_year from 
                        (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                    where 
                    left(AcNo,8) in ('4.02.02.') and AcNo <> '4.02.01.12' and (CAmt - DAmt) > 0
                    and left(DocDt,4) = LEFT('".$date."', 4)
                )z 
                on x.id_link=z.id_link
            ");

            // DETAIL
            $detail_pj_dom = DB::connection("pgsql")->select(
                "select 1 as id_link, b.trf_name,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 4 AND a.trx_date = ('".$tanggal."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') 
                group by b.trf_name "										
            );
            $detail_pj_asg = DB::connection("pgsql")->select(
                "select 2 as id_link, b.trf_name,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 4 AND a.trx_date = ('".$tanggal."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') 
                group by b.trf_name "										
            );
            $detail_pj_pkt = DB::connection("pgsql")->select(
                "select 3 as id_link, b.trf_name,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 4 AND a.trx_date = ('".$tanggal."') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%') 
                group by b.trf_name "										
            );
            $detail_in_dom = DB::connection("pgsql")->select(
                "select 1 as id_link, b.trf_name,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.ctg_id in (4,5,6) and a.group_id = 4 AND a.trx_date = ('".$tanggal."') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                group by b.trf_name"										
            );
            $detail_in_asg = DB::connection("pgsql")->select(
                "select 2 as id_link, b.trf_name,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.ctg_id not in (4,5,6) and a.group_id = 4 AND a.trx_date = ('".$tanggal."') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                group by b.trf_name "										
            );
            $detail_in_pkt = DB::connection("pgsql")->select(
                "select 3 as id_link, b.trf_name,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 4 AND a.trx_date = ('".$tanggal."')  AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                group by b.trf_name "										
            );
            $detail_in_not = DB::connection("mysql2")->select(
                "select 4 as id_link,AcDesc, sum(CAmt - DAmt) as actual_nominal_date from 
                (
                    select a.DocDt AS DocDt,c.AcDesc,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                    from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo))
                    join tblcoa c on (b.AcNo = c.AcNo))
                ) vwtwcjn
                where 
                left(AcNo,8) in ('4.02.02.') and AcNo <> '4.02.01.12' and (CAmt - DAmt) > 0
                and DocDt = '".$date."'
                group by AcDesc"										
            );
            // return $detail_in_not;
    
        }
        // RATUBOKO
        if($unit == 3){
            $ticketing = DB::connection("pgsql")->select("
                select w.id_link,TO_CHAR(('".$tanggal."')::date, 'yyyymmdd') as trx_date,w.deskripsi,case when x.total_trx > 0 then x.total_trx else 0 end as actual_trx_date,
                y.total_trx as actual_trx_month, z.total_trx as actual_trx_year
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                    union all
                    select 3 as id_link, 'Paket' as deskripsi
                )w
                left outer join
                (
                    select trx_date,id_link ,total_trx
                    from
                    (
                        (
                            select a.trx_date, 1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 5 AND a.trx_date = ('".$tanggal."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                            group by a.trx_date, id_link
                        )
                        union all
                        (
                            select a.trx_date, 2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 5 AND a.trx_date = ('".$tanggal."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                            group by a.trx_date, id_link
                        )
                        union all
                        (
                            select a.trx_date,3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.trx_date = ('".$tanggal."') AND ((b.trf_trfftype_id IN (2) and b.trf_name like '%Ratu Boko%' and b.trf_name not like '%Borobudur%') or (a.group_id = 5 and b.trf_name like '%Meals%')) and a.source_type not in ('B2B','OTA')
                            group by a.trx_date, id_link
                        )
                    )x
                )x on w.id_link = x.id_link
                left outer join
                (
                    select thbl,id_link,sum(total_trx) as total_trx 
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA')
                            group by thbl,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA')
                            group by thbl,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by thbl,  id_link
                            union all 
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id in (4,6) and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') AND b.trf_name like '%Boko%'
                            group by thbl,  id_link
                        )
                    )y
                    group by thbl,id_link
                )y on w.id_link = y.id_link
                left outer join
                (
                    select tahun,id_link,sum(total_trx) as total_trx
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by tahun,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by tahun,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by tahun,  id_link
                            union all 
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id in (4,6) and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') AND b.trf_name like '%Boko%'
                            group by tahun,  id_link
                        )
                    )z
                    group by tahun,id_link
                )z on w.id_link=z.id_link"
            );
            $income = DB::connection("pgsql")->select("
                        select w.id_link,TO_CHAR(('".$tanggal."')::date, 'yyyymmdd') as trx_date,w.deskripsi,case when x.total_nom > 0 then x.total_nom else 0 end as actual_nom_date,
                y.total_nom as actual_nom_month, z.total_nom as actual_nom_year
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                    union all
                    select 3 as id_link, 'Paket' as deskripsi
                )w
                left outer join
                (
                    select trx_date,id_link ,total_nom
                    from
                    (
                        (
                            select a.trx_date, 1 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 5 AND a.trx_date = ('".$tanggal."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                            group by a.trx_date, id_link
                        )
                        union all
                        (
                            select a.trx_date, 2 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 5 AND a.trx_date = ('".$tanggal."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                            group by a.trx_date, id_link
                        )
                        union all
                        (
                            select a.trx_date,3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.trx_date = ('".$tanggal."') AND ((b.trf_trfftype_id IN (2) and b.trf_name like '%Ratu Boko%' and b.trf_name not like '%Borobudur%') or (a.group_id = 5 and b.trf_name like '%Meals%')) and a.source_type not in ('B2B','OTA')
                            group by a.trx_date, id_link
                        )
                    )x
                )x on w.id_link = x.id_link
                left outer join
                (
                    select thbl,id_link,sum(total_nom) as total_nom 
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,1 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA')
                            group by thbl,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,2 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA')
                            group by thbl,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by thbl,  id_link
                            union all 
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id in (4,6) and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') AND b.trf_name like '%Boko%'
                            group by thbl,  id_link
                        )
                    )y
                    group by thbl,id_link
                )y on w.id_link = y.id_link
                left outer join
                (
                    select tahun,id_link,sum(total_nom) as total_nom
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,1 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by tahun,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,2 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by tahun,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by tahun,  id_link
                            union all 
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id in (4,6) and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') AND b.trf_name like '%Boko%'
                            group by tahun,  id_link
                        )
                    )z
                    group by tahun,id_link
                )z on w.id_link=z.id_link
            ");
            $erp = DB::connection("mysql2")->select("
                            select x.id_link,'".$date."' as trx_date,x.deskripsi,COALESCE(x.actual_nominal_date,0) as actual_nominal_date,COALESCE(y.actual_nominal_month,0) as actual_nominal_month,COALESCE(z.actual_nominal_year,0) as actual_nominal_year
                from
                (
                    select 4 as id_link,'".$date."' as DocDt,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_date from 
                    (
                        select 4 as id_link,AcNo,CAmt,DAmt from 
                                                                    (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                        where 
                        left(AcNo,8) in ('4.02.03.') and AcNo not in ('4.02.01.07','4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                        and DocDt =  '".$date."'
                        union all
                        select 4 as id_link,AcNo,CAmt,DAmt from 
                                                                    (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                        where 
                        AcNo in ('4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                        and DocDt = '".$date2."' 
                    )x
                )x
                left outer join 
                (
                    select 4 as id_link,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_month from 
                    (
                        select 4 as id_link,AcNo,CAmt,DAmt from 
                                                                    (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                        where 
                        left(AcNo,8) in ('4.02.03.') and AcNo not in ('4.02.01.07','4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                        and left(DocDt,6) = left('".$date."',6) 
                        union all
                        select 4 as id_link,AcNo,CAmt,DAmt from 
                                                                    (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                        where 
                        AcNo in ('4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                        and left(DocDt,6) = left('".$date2."',6) 
                    )x
                )y 
                on x.id_link = y.id_link
                left outer join 
                (
                    select 4 as id_link,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_year from 
                    (
                        select 4 as id_link,AcNo,CAmt,DAmt from 
                                                                    (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                        where 
                        left(AcNo,8) in ('4.02.03.') and AcNo not in ('4.02.01.07','4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                        and left(DocDt,4) = left('".$date."',4) 
                        union all
                        select 4 as id_link,AcNo,CAmt,DAmt from 
                                                                    (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                        where 
                        AcNo in ('4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                        and left(DocDt,4) = left('".$date2."',4)
                    )x
                )z 
                on x.id_link=z.id_link
            ");
            // DETAIL
            $detail_pj_dom = DB::connection("pgsql")->select(
                "select 1 as id_link, b.trf_name ,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 5 AND a.trx_date = ('".$tanggal."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                group by b.trf_name "                                               
            );
            $detail_pj_asg = DB::connection("pgsql")->select(
                "select 2 as id_link, b.trf_name,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 5 AND a.trx_date = ('".$tanggal."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                group by b.trf_name "
            );
            $detail_pj_pkt = DB::connection("pgsql")->select(
                "select 3 as id_link, b.trf_name,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.trx_date = ('".$tanggal."') AND ((b.trf_trfftype_id IN (2) and b.trf_name like '%Ratu Boko%' and b.trf_name not like '%Borobudur%') or (a.group_id = 5 and b.trf_name like '%Meals%')) and a.source_type not in ('B2B','OTA')
                group by b.trf_name "
            );
            $detail_in_dom = DB::connection("pgsql")->select(
                "select 1 as id_link, b.trf_name,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 5 AND a.trx_date = ('".$tanggal."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                group by b.trf_name "
            );
            $detail_in_asg = DB::connection("pgsql")->select(
                "select 2 as id_link, b.trf_name,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 5 AND a.trx_date = ('".$tanggal."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                group by b.trf_name "
            );
            $detail_in_pkt = DB::connection("pgsql")->select(
                "select 3 as id_link, b.trf_name,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.trx_date = ('".$tanggal."') AND ((b.trf_trfftype_id IN (2) and b.trf_name like '%Ratu Boko%' and b.trf_name not like '%Borobudur%') or (a.group_id = 5 and b.trf_name like '%Meals%')) and a.source_type not in ('B2B','OTA')
                group by b.trf_name "
            );
            $detail_in_not = DB::connection("mysql2")->select(
                "select 4 as id_link,AcDesc, sum(CAmt - DAmt) as actual_nominal_date from 
                (
                    select 4 as id_link,AcNo,AcDesc,CAmt,DAmt from 
                                    (
                    select a.DocDt AS DocDt,c.AcDesc,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                    from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo))
                    join tblcoa c on (b.AcNo = c.AcNo))
                ) vwtwcjn
                    where 
                    left(AcNo,8) in ('4.02.03.') and AcNo not in ('4.02.01.07','4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                    and DocDt = '".$date."' 
                    union all
                    select 4 as id_link,AcNo,AcDesc,CAmt,DAmt from 
                                    (
                    select a.DocDt AS DocDt,c.AcDesc,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                    from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo))
                    join tblcoa c on (b.AcNo = c.AcNo))
                ) vwtwcjn
                    where 
                    AcNo in ('4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                    and DocDt = '".$date2."' 
                )x
                group by AcDesc"										
            );
        }
        // TMII
        if($unit == 4){
            $ticketing = DB::connection('pgsql')->select("
                select w.id_link,TO_CHAR(('".$tanggal."')::date, 'yyyymmdd') as trx_date,w.deskripsi,
                case when x.total_trx > 0 then x.total_trx else 0 end as actual_trx_date,
                case when y.total_trx > 0 then y.total_trx else 0 end as actual_trx_month,
                case when z.total_trx > 0 then z.total_trx else 0 end as actual_trx_year,
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                    union all
                    select 3 as id_link, 'Paket' as deskripsi
                )w
                left outer join
                (
                    select trx_date,id_link ,total_trx
                    from
                    (
                        (
                            select a.trx_date, 1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 26 AND a.trx_date = ('".$tanggal."') and a.ctg_id in (4,5,6) AND b.trf_trfftype_id NOT IN (2) 
                            group by a.trx_date, id_link
                        )
                        union all
                        (
                            select a.trx_date, 2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 26 AND a.trx_date = ('".$tanggal."') and a.ctg_id not in (4,5,6) AND b.trf_trfftype_id NOT IN (2) 
                            group by a.trx_date, id_link
                        )
                        union all
                        (
                            select a.trx_date, 3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 26 AND a.trx_date = ('".$tanggal."') AND b.trf_trfftype_id IN (2)
                            group by a.trx_date, id_link
                        )
                    )x
                )x on w.id_link = x.id_link
                left outer join
                (
                    select thbl,id_link,total_trx as total_trx
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 26 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2)
                            group by thbl,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 26 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2)
                            group by thbl,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 26 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') AND b.trf_trfftype_id IN (2)
                            group by thbl,  id_link
                        )
                    )y
                )y on w.id_link = y.id_link
                left outer join
                (
                    select tahun,id_link,total_trx as total_trx
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 26 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) 
                            group by tahun,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 26 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2)
                            group by tahun,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 26 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') AND b.trf_trfftype_id IN (2) 
                            group by tahun,  id_link
                        )
                    )z
                )z on w.id_link=z.id_link
            ");
            $income = DB::connection('pgsql')->select("
                select w.id_link,TO_CHAR(('".$tanggal."')::date, 'yyyymmdd') as trx_date,w.deskripsi,
                case when x.total_nom > 0 then x.total_nom else 0 end as actual_nom_date,
                case when y.total_nom > 0 then y.total_nom else 0 end as actual_nom_month,
                case when z.total_nom > 0 then z.total_nom else 0 end as actual_nom_year
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                    union all
                    select 3 as id_link, 'Paket' as deskripsi
                )w
                left outer join
                (
                    select trx_date,id_link ,total_nom
                    from
                    (
                        (
                            select a.trx_date, 1 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 26 AND a.trx_date = ('".$tanggal."') and a.ctg_id in (4,5,6) AND b.trf_trfftype_id NOT IN (2) 
                            group by a.trx_date, id_link
                        )
                        union all
                        (
                            select a.trx_date, 2 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 26 AND a.trx_date = ('".$tanggal."') and a.ctg_id not in (4,5,6) AND b.trf_trfftype_id NOT IN (2) 
                            group by a.trx_date, id_link
                        )
                        union all
                        (
                            select a.trx_date, 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 26 AND a.trx_date = ('".$tanggal."') AND b.trf_trfftype_id IN (2)
                            group by a.trx_date, id_link
                        )
                    )x
                )x on w.id_link = x.id_link
                left outer join
                (
                    /versi month/
                    select thbl,id_link,total_nom  as total_nom
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,1 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 26 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2)
                            group by thbl,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,2 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 26 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2)
                            group by thbl,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyymm') as thbl,3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 26 and TO_CHAR(a.trx_date::date, 'yyyymm') = TO_CHAR(('".$tanggal."')::date, 'yyyymm') AND b.trf_trfftype_id IN (2)
                            group by thbl,  id_link
                        )
                    )y
                )y on w.id_link = y.id_link
                left outer join
                (
                    /versi year/
                    select tahun,id_link,total_nom as total_nom
                    from
                    (
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,1 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 26 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) 
                            group by tahun,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,2 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 26 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2)
                            group by tahun,  id_link
                        )
                        union all
                        (
                            select TO_CHAR(a.trx_date::date, 'yyyy') as tahun,3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 26 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tanggal."')::date, 'yyyy') AND b.trf_trfftype_id IN (2) 
                            group by tahun,  id_link
                        )
                    )z
                )z on w.id_link = z.id_link
            ");
        }
        // MANOHARA
        if($unit == 5){
            $ticketing = DB::connection("pgsql")->select("
                select w.id_link,w.deskripsi,
                case when x.total_trx > 0 then x.total_trx else 0 end as actual_trx_date,
                case when y.total_trx > 0 then y.total_trx else 0 end as actual_trx_month,
                case when z.total_trx > 0 then z.total_trx else 0 end as actual_trx_year
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                )w
                left outer join
                (
                    /versi date/
                    select id_link ,total_trx
                    from
                    (
                        (
                            select 1 as id_link, sum(qty) as total_trx
                            from manohara_trans_ticket 
                            where DATE_FORMAT(transaction_time, '%Y%m%d') =  '20230410' and (category = 'WISNUS' or (category = 'INHOUSE' and country = 'Indonesia'))
                            group by id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(qty) as total_trx
                            from manohara_trans_ticket 
                            where DATE_FORMAT(transaction_time, '%Y%m%d') =  '20230410' and (category = 'WISMAN' or (category = 'INHOUSE' and country <> 'Indonesia'))
                            group by id_link
                        )
                    )x
                )x on w.id_link = x.id_link
                left outer join
                (
                    /versi month/
                    select id_link, total_trx
                    from
                    (
                        (
                            select 1 as id_link, sum(qty) as total_trx
                            from manohara_trans_ticket 
                            where DATE_FORMAT(transaction_time, '%Y%m') =  '202304' and (category = 'WISNUS' or (category = 'INHOUSE' and country = 'Indonesia'))
                            group by id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(qty) as total_trx
                            from manohara_trans_ticket 
                            where DATE_FORMAT(transaction_time, '%Y%m') =  '202304' and (category = 'WISMAN' or (category = 'INHOUSE' and country <> 'Indonesia'))
                            group by id_link
                        )
                    )y
                )y on w.id_link = y.id_link
                left outer join
                (
                    /versi year/
                    select id_link,total_trx
                    from
                    (
                        (
                            select 1 as id_link, sum(qty) as total_trx
                            from manohara_trans_ticket 
                            where DATE_FORMAT(transaction_time, '%Y') =  '2023' and (category = 'WISNUS' or (category = 'INHOUSE' and country = 'Indonesia'))
                            group by id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(qty) as total_trx
                            from manohara_trans_ticket 
                            where DATE_FORMAT(transaction_time, '%Y') =  '2023' and (category = 'WISMAN' or (category = 'INHOUSE' and country <> 'Indonesia'))
                            group by id_link
                        )
                    )z
                )z on w.id_link = z.id_link
            ");
            $income = DB::connection("pgsql")->select("
                select w.id_link,w.deskripsi,
                case when x.total_nom > 0 then x.total_nom else 0 end as actual_nom_date,
                case when y.total_nom > 0 then y.total_nom else 0 end as actual_nom_month,
                case when z.total_nom > 0 then z.total_nom else 0 end as actual_nom_year
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                )w
                left outer join
                (
                    /versi date/
                    select id_link ,total_nom
                    from
                    (
                        (
                            select 1 as id_link, sum(subtotal) as total_nom
                            from manohara_trans_ticket 
                            where DATE_FORMAT(transaction_time, '%Y%m%d') =  '20230410' and (category = 'WISNUS' or (category = 'INHOUSE' and country = 'Indonesia'))
                            group by id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(subtotal) as total_nom
                            from manohara_trans_ticket 
                            where DATE_FORMAT(transaction_time, '%Y%m%d') =  '20230410' and (category = 'WISMAN' or (category = 'INHOUSE' and country <> 'Indonesia'))
                            group by id_link
                        )
                    )x
                )x on w.id_link = x.id_link
                left outer join
                (
                    /versi month/
                    select id_link, total_nom
                    from
                    (
                        (
                            select 1 as id_link, sum(subtotal) as total_nom
                            from manohara_trans_ticket 
                            where DATE_FORMAT(transaction_time, '%Y%m') =  '202304' and (category = 'WISNUS' or (category = 'INHOUSE' and country = 'Indonesia'))
                            group by id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(subtotal) as total_nom
                            from manohara_trans_ticket 
                            where DATE_FORMAT(transaction_time, '%Y%m') =  '202304' and (category = 'WISMAN' or (category = 'INHOUSE' and country <> 'Indonesia'))
                            group by id_link
                        )
                    )y
                )y on w.id_link = y.id_link
                left outer join
                (
                    /versi year/
                    select id_link,total_nom
                    from
                    (
                        (
                            select 1 as id_link, sum(subtotal) as total_nom
                            from manohara_trans_ticket 
                            where DATE_FORMAT(transaction_time, '%Y') =  '2023' and (category = 'WISNUS' or (category = 'INHOUSE' and country = 'Indonesia'))
                            group by id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(subtotal) as total_nom
                            from manohara_trans_ticket 
                            where DATE_FORMAT(transaction_time, '%Y') =  '2023' and (category = 'WISMAN' or (category = 'INHOUSE' and country <> 'Indonesia'))
                            group by id_link
                        )
                    )z
                )z on w.id_link = z.id_link
            ");
        }
        $target_pengguna_jasa = DB::connection("mysql3")->select("
            SELECT x.id_link, x.target AS target_mountly, y.target AS target_yearly FROM
            (
                SELECT y.id_link, x.target 
                FROM new_master_target_volume x
                left OUTER JOIN new_master_category Y
                ON x.id_category = y.id
                left outer join  new_master_unit z
                on y.id_unit = z.id
                WHERE x.bulan = right(left('".$date."',6),2) and z.id = ".$unit."
            )x
            LEFT OUTER JOIN 
            (
                SELECT y.id_link, SUM(x.target) AS target
                FROM new_master_target_volume x
                left OUTER JOIN new_master_category Y
                ON x.id_category = y.id
                left outer join  new_master_unit z
                on y.id_unit = z.id
                    WHERE x.tahun = left('".$date."',4) and z.id = ".$unit."
                GROUP BY y.id_link
            )Y
            ON x.id_link = y.id_link"
        );
        // return $target_pengguna_jasa;
        $target_income = DB::connection("mysql3")->select("
            SELECT x.id_link, x.target AS target_mountly, y.target AS target_yearly FROM
            (
                SELECT y.id_link, SUM(x.target) AS target 
                FROM new_master_target_income x
                left OUTER JOIN new_master_category Y
                ON x.id_category = y.id
                left outer join  new_master_unit z
                on y.id_unit = z.id
                WHERE x.bulan = right(left('".$date."',6),2) and z.id = ".$unit."
                GROUP BY y.id_link
            )x
            LEFT OUTER JOIN 
            (
                SELECT y.id_link, SUM(x.target) AS target
                FROM new_master_target_income x
                left OUTER JOIN new_master_category Y
                ON x.id_category = y.id
                left outer join  new_master_unit z
                on y.id_unit = z.id
                WHERE x.tahun = left('".$date."',4) and z.id = ".$unit."
                GROUP BY y.id_link
            )Y
            ON x.id_link = y.id_link
            group by x.id_link,x.target,y.target
        ");
        $target_income_non = DB::connection("mysql3")->select("
            SELECT x.id_link, x.target AS target_mountly, y.target AS target_yearly FROM
            (
                SELECT y.id_link, x.target 
                FROM new_master_target_income x
                left OUTER JOIN new_master_category Y
                ON x.id_category = y.id
                left outer join  new_master_unit z
                on y.id_unit = z.id
                WHERE x.bulan = right(left('".$date."',6),2) and z.id = ".$unit." and y.id_link = 4
                GROUP BY y.id_link,x.target
            )x
            LEFT OUTER JOIN 
            (
                SELECT y.id_link, SUM(x.target) AS target
                FROM new_master_target_income x
                left OUTER JOIN new_master_category Y
                ON x.id_category = y.id
                left outer join  new_master_unit z
                on y.id_unit = z.id
                WHERE x.tahun = left('".$date."',4) and z.id = ".$unit." and y.id_link = 4
                GROUP BY y.id_link,x.target
            )Y
            ON x.id_link = y.id_link
            group by x.id_link,x.target,y.target
        ");

        $count = count($target_pengguna_jasa);

        $data = [
            'ticketing'=>$ticketing,
            'target_pengguna_jasa'=>$target_pengguna_jasa,
            'income'=>$income,
            'target_income'=>$target_income,
            'erp'=>$erp,
            'naik_candi'=>$naik_candi,
            'naik_candi_act'=>$naik_candi_act,
            'naik_candi_mtd'=>$naik_candi_mtd,
            'naik_candi_mtd_i'=>$naik_candi_mtd_i,
            'naik_candi_ytd'=>$naik_candi_ytd,
            'naik_candi_ytd_i'=>$naik_candi_ytd_i,
            'tgt_naik_candi_m'=>$tgt_naik_candi_m,
            'tgt_naik_candi_y'=>$tgt_naik_candi_y,
            'target_income_non'=>$target_income_non,
            'price_naik_candi'=>$price_naik_candi,
            'acv_mtd'=>$acv_mtd,
            'count'=>$count,
            'unit'=>$unit,
            'tanggal'=>$tanggal,
            'detail_pj_dom'=>$detail_pj_dom,
            'detail_pj_asg'=>$detail_pj_asg,
            'detail_pj_pkt'=>$detail_pj_pkt,
            'detail_in_dom'=>$detail_in_dom,
            'detail_in_asg'=>$detail_in_asg,
            'detail_in_pkt'=>$detail_in_pkt,
            'detail_in_not'=>$detail_in_not,
            'tgl_start'=>$tgl_start,
            'tgl_end'=>$tgl_end
        ];
        return view("report_page",$data);
    }
    public function filter($unit,$tgl_start,$tgl_end)
    {
        if(date("Y",strtotime($tgl_start)) != date("Y",strtotime($tgl_end))){
            return redirect()->back()->with("gagal","tahun");
        }
        // 1 == borobudur
        // 2 == prambanan
        // 3 == ratuboko

        if($unit == "borobudur"){
            $unit = 1;
        }elseif($unit == "prambanan"){
            $unit = 2;
        }elseif($unit == "ratuboko"){
            $unit = 3;
        }
        else{
            return view("home");
        }

        $date_start = str_replace("-","",$tgl_start);//FORMAT FILTER TANPA STRIP (ERP)

        $date_end = str_replace("-","",$tgl_end);//FORMAT FILTER TANPA STRIP (ERP)

        $date2_start = date("Ymd",strtotime($tgl_start.' - 1 days')); //FILTER - 1
        $date2_end = date("Ymd",strtotime($tgl_end.' - 1 days')); //FILTER - 1

        // BOROBUDUR
        if($unit == 1){
            $ticketing = DB::connection("pgsql")->select("
                        select w.id_link,w.deskripsi,case when x.total_trx > 0 then x.total_trx else 0 end as actual_trx_date,
                y.total_trx as actual_trx_month, z.total_trx as actual_trx_year
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                    union all
                    select 3 as id_link, 'Paket' as deskripsi
                )w
                left outer join
                (
                    select id_link ,total_trx
                    from
                    (
                        (
                            select 1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') 
                            group by id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and trf_name not like '%Prahastiwi%') 
                            group by id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%') 
                            group by id_link
                        )
                    )x
                )x on w.id_link = x.id_link
                left outer join
                (
                    select id_link,total_trx as total_trx
                    from
                    (
                        (
                            select 1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 6 and ( TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR('".$tgl_start."'::date, 'yyyymm')  and TO_CHAR('".$tgl_end."'::date, 'yyyymm')) and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 6 and ( TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR('".$tgl_start."'::date, 'yyyymm')  and TO_CHAR('".$tgl_end."'::date, 'yyyymm')) and a.ctg_id not in (4,5,6) and (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and trf_name not like '%Prahastiwi%')
                            group by id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 6 and ( TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR('".$tgl_start."'::date, 'yyyymm')  and TO_CHAR('".$tgl_end."'::date, 'yyyymm')) AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by id_link
                        )
                    )y
                )y on w.id_link = y.id_link
                left outer join
                (
                    select id_link,total_trx as total_trx
                    from
                    (
                        (
                            select 1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 6 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 6 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') and a.ctg_id not in (4,5,6) and (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and trf_name not like '%Prahastiwi%')
                            group by id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 6 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by id_link
                        )
                    )z
                )z on w.id_link=z.id_link"
            );
            $income = DB::connection("pgsql")->select("
                        select w.id_link,w.deskripsi,case when x.total_nom > 0 then x.total_nom else 0 end as actual_nom_date,
                y.total_nom as actual_nom_month, z.total_nom as actual_nom_year
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                    union all
                    select 3 as id_link, 'Paket' as deskripsi
                )w
                left outer join
                (
                    select id_link,total_nom
                    from
                    (
                        (
                            select
                            case when a.ctg_id in (4,5,6) then 1
                            else 2 end as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                            group by id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."')  AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                            group by id_link
                        )
                    )x
                )x 
                on w.id_link = x.id_link
                left outer join
                (
                    select id_link,total_nom
                    from
                    (
                        (
                            select
                            case when a.ctg_id in (4,5,6) then 1
                            else 2 end as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND (TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR(('".$tgl_start."')::date, 'yyyymm') and TO_CHAR(('".$tgl_end."')::date, 'yyyymm')) AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                            group by id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND (TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR(('".$tgl_start."')::date, 'yyyymm') and TO_CHAR(('".$tgl_end."')::date, 'yyyymm')) AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                            group by id_link
                        )
                    )y
                )y on w.id_link = y.id_link
                left outer join
                (
                    select id_link,total_nom
                    from
                    (
                        (
                            select
                            case when a.ctg_id in (4,5,6) then 1
                            else 2 end as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                            group by id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 6 AND TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy')  AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                            group by id_link
                        )
                    )z
                )z on w.id_link=z.id_link
            ");
            $erp = DB::connection("mysql2")->select("
                            select x.id_link, x.deskripsi,COALESCE(x.actual_nominal_date,0) as actual_nominal_date,COALESCE(y.actual_nominal_month,0) as actual_nominal_month,COALESCE(z.actual_nominal_year,0) as actual_nominal_year
                from
                (
                    select 4 as id_link,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_date from 
                        (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                    where 
                    left(AcNo,8) in ('4.02.02.') and AcNo <> '4.02.01.12' and (CAmt - DAmt) > 0
                    and (DocDt between '".$date_start."' and '".$date_end."')
                )x
                left outer join 
                (
                    select 4 as id_link,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_month from 
                        (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                    where 
                    left(AcNo,8) in ('4.02.02.') and AcNo <> '4.02.01.12' and (CAmt - DAmt) > 0
                    and (left(DocDt,6) between LEFT('".$date_start."', 6) and LEFT('".$date_end."', 6))
                )y 
                on x.id_link = y.id_link
                left outer join 
                (
                    select 4 as id_link,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_year from 
                        (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                    where 
                    left(AcNo,8) in ('4.02.02.') and AcNo <> '4.02.01.12' and (CAmt - DAmt) > 0
                    and left(DocDt,4) = LEFT('".$date_end."', 4)
                )z 
                on x.id_link=z.id_link
            ");
            // DETAIL
            $detail_pj_dom = DB::connection("pgsql")->select(
                "select 1 as id_link, b.trf_name, sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 6 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%')
                group by b.trf_name"                                             
            );
            $detail_pj_asg = DB::connection("pgsql")->select(
                "select 2 as id_link, b.trf_name,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 6 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and trf_name not like '%Prahastiwi%')
                group by b.trf_name"
            );
            $detail_pj_pkt = DB::connection("pgsql")->select(
                "select 3 as id_link, b.trf_name,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 6 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%') 
                group by b.trf_name "
            );
            $detail_in_dom = DB::connection("pgsql")->select(
                "select 1 as id_link, b.trf_name ,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.ctg_id in (4,5,6) and a.group_id = 6 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                group by b.trf_name"                                                  
            );
            $detail_in_asg = DB::connection("pgsql")->select(
                "select 2 as id_link, b.trf_name ,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.ctg_id not in (4,5,6) and a.group_id = 6 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                group by b.trf_name"           
            );
            $detail_in_pkt = DB::connection("pgsql")->select(
                "select 3 as id_link, b.trf_name,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 6 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."')  AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                group by b.trf_name"          
            );
            $detail_in_not = DB::connection("mysql2")->select(
                "select 4 as id_link,AcDesc, sum(CAmt - DAmt) as actual_nominal_date from 
                (
                    select a.DocDt AS DocDt,c.AcDesc,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                    from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo))
                    join tblcoa c on (b.AcNo = c.AcNo))
                ) vwtwcjn
                where 
                left(AcNo,8) in ('4.02.01.') and AcNo <> '4.02.01.11' and (CAmt - DAmt) > 0
                and (DocDt between '".$date_start."' and '".$date_end."') 
                group by AcDesc "										
            );
        }
        // PRAMBANAN
        if($unit == 2){
            $ticketing = DB::connection("pgsql")->select("
                select w.id_link,w.deskripsi,case when x.total_trx > 0 then x.total_trx else 0 end as actual_trx_date,
                y.total_trx as actual_trx_month, z.total_trx as actual_trx_year
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                    union all
                    select 3 as id_link, 'Paket' as deskripsi
                )w
                left outer join
                (
                    select id_link ,total_trx
                    from
                    (
                        (
                            select 1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') 
                            group by id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') 
                            group by id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%') 
                            group by id_link
                        )
                    )x
                )x on w.id_link = x.id_link
                left outer join
                (
                    select id_link,total_trx as total_trx
                    from
                    (
                        (
                            select 1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 4 and ( TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR('".$tgl_start."'::date, 'yyyymm')  and TO_CHAR('".$tgl_end."'::date, 'yyyymm')) and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by  id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 4 and ( TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR('".$tgl_start."'::date, 'yyyymm')  and TO_CHAR('".$tgl_end."'::date, 'yyyymm')) and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by  id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 4 and ( TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR('".$tgl_start."'::date, 'yyyymm')  and TO_CHAR('".$tgl_end."'::date, 'yyyymm')) AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by  id_link
                        )
                    )y
                )y on w.id_link = y.id_link
                left outer join
                (
                    select id_link,total_trx as total_trx
                    from
                    (
                        (
                            select 1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 4 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 4 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 4 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by id_link
                        )
                    )z
                )z on w.id_link = z.id_link"
            );
            $income = DB::connection("pgsql")->select("
                select w.id_link,w.deskripsi,case when x.total_nom > 0 then x.total_nom else 0 end as actual_nom_date,
                y.total_nom as actual_nom_month, z.total_nom as actual_nom_year
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                    union all
                    select 3 as id_link, 'Paket' as deskripsi
                )w
                left outer join
                (
                    select id_link,total_nom
                    from
                    (
                        (
                            select
                            case when a.ctg_id in (4,5,6) then 1
                            else 2 end as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                            group by id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."')  AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                            group by id_link
                        )
                    )x
                )x 
                on w.id_link = x.id_link
                left outer join
                (
                    select id_link,total_nom
                    from
                    (
                        (
                            select
                            case when a.ctg_id in (4,5,6) then 1
                            else 2 end as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND (TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR(('".$tgl_start."')::date, 'yyyymm') and TO_CHAR(('".$tgl_end."')::date, 'yyyymm')) AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                            group by id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND (TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR(('".$tgl_start."')::date, 'yyyymm') and TO_CHAR(('".$tgl_end."')::date, 'yyyymm')) AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                            group by id_link
                        )
                    )y
                )y on w.id_link = y.id_link
                left outer join
                (
                    select id_link,total_nom
                    from
                    (
                        (
                            select
                            case when a.ctg_id in (4,5,6) then 1
                            else 2 end as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                            group by id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 4 AND TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy')  AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                            group by id_link
                        )
                    )z
                )z on w.id_link=z.id_link
            ");
            $erp = DB::connection("mysql2")->select("
                            select x.id_link,x.deskripsi,COALESCE(x.actual_nominal_date,0) as actual_nominal_date,COALESCE(y.actual_nominal_month,0) as actual_nominal_month,COALESCE(z.actual_nominal_year,0) as actual_nominal_year
                from
                (
                    select 4 as id_link,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_date from 
                        (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                    where 
                    left(AcNo,8) in ('4.02.02.') and AcNo <> '4.02.01.12' and (CAmt - DAmt) > 0
                    and (DocDt between '".$date_start."' and '".$date_end."')
                )x
                left outer join 
                (
                    select 4 as id_link,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_month from 
                        (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                    where 
                    left(AcNo,8) in ('4.02.02.') and AcNo <> '4.02.01.12' and (CAmt - DAmt) > 0
                    and (left(DocDt,6) between LEFT('".$date_start."', 6) and LEFT('".$date_end."', 6))
                )y 
                on x.id_link = y.id_link
                left outer join 
                (
                    select 4 as id_link,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_year from 
                        (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                    where 
                    left(AcNo,8) in ('4.02.02.') and AcNo <> '4.02.01.12' and (CAmt - DAmt) > 0
                    and left(DocDt,4) = LEFT('".$date_end."', 4)
                )z 
                on x.id_link=z.id_link
            ");

            // DETAIL
            $detail_pj_dom = DB::connection("pgsql")->select(
                "select 1 as id_link, b.trf_name,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 4 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') 
                group by b.trf_name "										
            );
            $detail_pj_asg = DB::connection("pgsql")->select(
                "select 2 as id_link, b.trf_name,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 4 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') 
                group by b.trf_name "										
            );
            $detail_pj_pkt = DB::connection("pgsql")->select(
                "select 3 as id_link, b.trf_name,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 4 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%') 
                group by b.trf_name "										
            );
            $detail_in_dom = DB::connection("pgsql")->select(
                "select 1 as id_link, b.trf_name,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.ctg_id in (4,5,6) and a.group_id = 4 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                group by b.trf_name"										
            );
            $detail_in_asg = DB::connection("pgsql")->select(
                "select 2 as id_link, b.trf_name,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.ctg_id not in (4,5,6) and a.group_id = 4 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') AND b.trf_trfftype_id NOT IN (2) and b.trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA') 
                group by b.trf_name "										
            );
            $detail_in_pkt = DB::connection("pgsql")->select(
                "select 3 as id_link, b.trf_name,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 4 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."')  AND (b.trf_trfftype_id IN (2) or b.trf_name like '%Meals%') and a.source_type not in ('B2B','OTA')
                group by b.trf_name "										
            );
            $detail_in_not = DB::connection("mysql2")->select(
                "select 4 as id_link,AcDesc, sum(CAmt - DAmt) as actual_nominal_date from 
                (
                    select a.DocDt AS DocDt,c.AcDesc,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                    from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo))
                    join tblcoa c on (b.AcNo = c.AcNo))
                ) vwtwcjn
                where 
                left(AcNo,8) in ('4.02.02.') and AcNo <> '4.02.01.12' and (CAmt - DAmt) > 0
                and (DocDt between '".$date_start."' and '".$date_end."')
                group by AcDesc"										
            );
            // return $detail_in_not;
    
        }
            // RATUBOKO
        if($unit == 3){
            $ticketing = DB::connection("pgsql")->select("
                select w.id_link,w.deskripsi,case when x.total_trx > 0 then x.total_trx else 0 end as actual_trx_date,
                y.total_trx as actual_trx_month, z.total_trx as actual_trx_year
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                    union all
                    select 3 as id_link, 'Paket' as deskripsi
                )w
                left outer join
                (
                    select id_link ,total_trx
                    from
                    (
                        (
                            select 1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 5 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                            group by  id_link
                        )
                        union all
                        (
                            select  2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 5 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                            group by  id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE (a.trx_date between '".$tgl_start."' and '".$tgl_end."') AND ((b.trf_trfftype_id IN (2) and b.trf_name like '%Ratu Boko%' and b.trf_name not like '%Borobudur%') or (a.group_id = 5 and b.trf_name like '%Meals%')) and a.source_type not in ('B2B','OTA')
                            group by  id_link
                        )
                    )x
                )x on w.id_link = x.id_link
                left outer join
                (
                    select id_link,sum(total_trx) as total_trx 
                    from
                    (
                        (
                            select 1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and ( TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR('".$tgl_start."'::date, 'yyyymm')  and TO_CHAR('".$tgl_end."'::date, 'yyyymm')) and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA')
                            group by  id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and ( TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR('".$tgl_start."'::date, 'yyyymm')  and TO_CHAR('".$tgl_end."'::date, 'yyyymm')) and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA')
                            group by  id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and ( TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR('".$tgl_start."'::date, 'yyyymm')  and TO_CHAR('".$tgl_end."'::date, 'yyyymm')) AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by  id_link
                            union all 
                            select 3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id in (4,6) and ( TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR('".$tgl_start."'::date, 'yyyymm')  and TO_CHAR('".$tgl_end."'::date, 'yyyymm')) AND b.trf_name like '%Boko%'
                            group by  id_link
                        )
                    )y
                    group by id_link
                )y on w.id_link = y.id_link
                left outer join
                (
                    select id_link,sum(total_trx) as total_trx
                    from
                    (
                        (
                            select 1 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by id_link
                            union all 
                            select 3 as id_link, sum(a.tot_trx) as total_trx
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id in (4,6) and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') AND b.trf_name like '%Boko%'
                            group by id_link
                        )
                    )z
                    group by id_link
                )z on w.id_link=z.id_link"
            );
            $income = DB::connection("pgsql")->select("
                        select w.id_link,w.deskripsi,case when x.total_nom > 0 then x.total_nom else 0 end as actual_nom_date,
                y.total_nom as actual_nom_month, z.total_nom as actual_nom_year
                from
                (
                    select 1 as id_link, 'Domestik' as deskripsi
                    union all
                    select 2 as id_link, 'Asing' as deskripsi
                    union all
                    select 3 as id_link, 'Paket' as deskripsi
                )w
                left outer join
                (
                    select id_link ,total_nom
                    from
                    (
                        (
                            select 1 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 5 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                            group by id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE a.group_id = 5 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                            group by id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            WHERE (a.trx_date between '".$tgl_start."' and '".$tgl_end."') AND ((b.trf_trfftype_id IN (2) and b.trf_name like '%Ratu Boko%' and b.trf_name not like '%Borobudur%') or (a.group_id = 5 and b.trf_name like '%Meals%')) and a.source_type not in ('B2B','OTA')
                            group by id_link
                        )
                    )x
                )x on w.id_link = x.id_link
                left outer join
                (
                    select id_link,sum(total_nom) as total_nom 
                    from
                    (
                        (
                            select 1 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and (TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR(('".$tgl_start."')::date, 'yyyymm') and TO_CHAR(('".$tgl_end."')::date, 'yyyymm')) and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA')
                            group by   id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and (TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR(('".$tgl_start."')::date, 'yyyymm') and TO_CHAR(('".$tgl_end."')::date, 'yyyymm')) and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%' and a.source_type not in ('B2B','OTA')
                            group by   id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and (TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR(('".$tgl_start."')::date, 'yyyymm') and TO_CHAR(('".$tgl_end."')::date, 'yyyymm')) AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by   id_link
                            union all 
                            select 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id in (4,6) and (TO_CHAR(a.trx_date::date, 'yyyymm') between TO_CHAR(('".$tgl_start."')::date, 'yyyymm') and TO_CHAR(('".$tgl_end."')::date, 'yyyymm')) AND b.trf_name like '%Boko%'
                            group by   id_link
                        )
                    )y
                    group by id_link
                )y on w.id_link = y.id_link
                left outer join
                (
                    select id_link,sum(total_nom) as total_nom
                    from
                    (
                        (
                            select 1 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') and a.ctg_id in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by   id_link
                        )
                        union all
                        (
                            select 2 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') and a.ctg_id not in (4,5,6) and b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%'
                            group by   id_link
                        )
                        union all
                        (
                            select 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id = 5 and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') AND (b.trf_trfftype_id IN (2) or trf_name like '%Meals%')
                            group by   id_link
                            union all 
                            select 3 as id_link, sum(a.tot_nom) as total_nom
                            from recap_purchase a
                            left outer join
                            master_tariff b 
                            on a.trf_id = b.trf_id
                            where a.group_id in (4,6) and TO_CHAR(a.trx_date::date, 'yyyy') = TO_CHAR(('".$tgl_end."')::date, 'yyyy') AND b.trf_name like '%Boko%'
                            group by   id_link
                        )
                    )z
                    group by id_link
                )z on w.id_link=z.id_link
            ");
            $erp = DB::connection("mysql2")->select("
                            select x.id_link,x.deskripsi,COALESCE(x.actual_nominal_date,0) as actual_nominal_date,COALESCE(y.actual_nominal_month,0) as actual_nominal_month,COALESCE(z.actual_nominal_year,0) as actual_nominal_year
                from
                (
                    select 4 as id_link,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_date from 
                    (
                        select 4 as id_link,AcNo,CAmt,DAmt from 
                                                                    (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                        where 
                        left(AcNo,8) in ('4.02.03.') and AcNo not in ('4.02.01.07','4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                        and (DocDt between '".$date_start."' and '".$date_end."')
                        union all
                        select 4 as id_link,AcNo,CAmt,DAmt from 
                                                                    (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                        where 
                        AcNo in ('4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                        and (DocDt between '".$date2_start."' and '".$date2_end."') 
                    )x
                )x
                left outer join 
                (
                    select 4 as id_link,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_month from 
                    (
                        select 4 as id_link,AcNo,CAmt,DAmt from 
                                                                    (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                        where 
                        left(AcNo,8) in ('4.02.03.') and AcNo not in ('4.02.01.07','4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                        and (left(DocDt,6) between LEFT('".$date_start."', 6) and LEFT('".$date_end."', 6)) 
                        union all
                        select 4 as id_link,AcNo,CAmt,DAmt from 
                                                                    (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                        where 
                        AcNo in ('4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                        and (left(DocDt,6) between LEFT('".$date2_start."', 6) and LEFT('".$date2_end."', 6))
                    )x
                )y 
                on x.id_link = y.id_link
                left outer join 
                (
                    select 4 as id_link,'Non Paket/Aneka Usaha' as deskripsi, sum(CAmt - DAmt) as actual_nominal_year from 
                    (
                        select 4 as id_link,AcNo,CAmt,DAmt from 
                                                                    (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                        where 
                        left(AcNo,8) in ('4.02.03.') and AcNo not in ('4.02.01.07','4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                        and left(DocDt,4) = left('".$date_end."',4) 
                        union all
                        select 4 as id_link,AcNo,CAmt,DAmt from 
                                                                    (
                            select a.DocDt AS DocDt,b.AcNo AS AcNo,b.CAmt, b.DAmt
                            from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo)))
                        ) vwtwcjn
                        where 
                        AcNo in ('4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                        and left(DocDt,4) = left('".$date2_end."',4)
                    )x
                )z 
                on x.id_link=z.id_link
            ");
            // DETAIL
            $detail_pj_dom = DB::connection("pgsql")->select(
                "select 1 as id_link, b.trf_name ,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 5 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                group by b.trf_name "                                               
            );
            $detail_pj_asg = DB::connection("pgsql")->select(
                "select 2 as id_link, b.trf_name,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 5 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                group by b.trf_name "
            );
            $detail_pj_pkt = DB::connection("pgsql")->select(
                "select 3 as id_link, b.trf_name,sum(a.tot_trx) as total_trx
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE (a.trx_date between '".$tgl_start."' and '".$tgl_end."') AND ((b.trf_trfftype_id IN (2) and b.trf_name like '%Ratu Boko%' and b.trf_name not like '%Borobudur%') or (a.group_id = 5 and b.trf_name like '%Meals%')) and a.source_type not in ('B2B','OTA')
                group by b.trf_name "
            );
            $detail_in_dom = DB::connection("pgsql")->select(
                "select 1 as id_link, b.trf_name,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 5 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                group by b.trf_name "
            );
            $detail_in_asg = DB::connection("pgsql")->select(
                "select 2 as id_link, b.trf_name,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE a.group_id = 5 AND (a.trx_date between '".$tgl_start."' and '".$tgl_end."') and a.ctg_id not in (4,5,6) AND (b.trf_trfftype_id NOT IN (2) and trf_name not like '%Meals%') and a.source_type not in ('B2B','OTA') 
                group by b.trf_name "
            );
            $detail_in_pkt = DB::connection("pgsql")->select(
                "select 3 as id_link, b.trf_name,sum(a.tot_nom) as total_nom
                from recap_purchase a
                left outer join
                master_tariff b 
                on a.trf_id = b.trf_id
                WHERE (a.trx_date between '".$tgl_start."' and '".$tgl_end."') AND ((b.trf_trfftype_id IN (2) and b.trf_name like '%Ratu Boko%' and b.trf_name not like '%Borobudur%') or (a.group_id = 5 and b.trf_name like '%Meals%')) and a.source_type not in ('B2B','OTA')
                group by b.trf_name "
            );
            $detail_in_not = DB::connection("mysql2")->select(
                "select 4 as id_link,AcDesc, sum(CAmt - DAmt) as actual_nominal_date from 
                (
                    select 4 as id_link,AcNo,AcDesc,CAmt,DAmt from 
                                    (
                    select a.DocDt AS DocDt,c.AcDesc,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                    from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo))
                    join tblcoa c on (b.AcNo = c.AcNo))
                ) vwtwcjn
                    where 
                    left(AcNo,8) in ('4.02.03.') and AcNo not in ('4.02.01.07','4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                    and (DocDt between '".$date_start."' and '".$date_end."') 
                    union all
                    select 4 as id_link,AcNo,AcDesc,CAmt,DAmt from 
                                    (
                    select a.DocDt AS DocDt,c.AcDesc,b.AcNo AS AcNo,b.CAmt, b.DAmt 
                    from ((tbljournalhdr a join tbljournaldtl b on(a.DocNo = b.DocNo))
                    join tblcoa c on (b.AcNo = c.AcNo))
                ) vwtwcjn
                    where 
                    AcNo in ('4.02.03.05.01','4.02.03.05.02','4.02.03.05.03') and (CAmt - DAmt) > 0
                    and (DocDt between '".$date2_start."' and '".$date2_end."') 
                )x
                group by AcDesc"										
            );
        }
        $target_pengguna_jasa = DB::connection("mysql3")->select("
            SELECT x.id_link, x.target AS target_mountly, y.target AS target_yearly FROM
            (
                SELECT y.id_link, SUM(x.target) AS target
                FROM new_master_target_volume x
                left OUTER JOIN new_master_category Y
                ON x.id_category = y.id
                left outer join  new_master_unit z
                on y.id_unit = z.id
                WHERE (x.thbl between left('".$date_start."',6) and left('".$date_end."',6)) and z.id = ".$unit."
                group by y.id_link
            )x
            LEFT OUTER JOIN 
            (
                SELECT y.id_link, SUM(x.target) AS target
                FROM new_master_target_volume x
                left OUTER JOIN new_master_category Y
                ON x.id_category = y.id
                left outer join  new_master_unit z
                on y.id_unit = z.id
                    WHERE x.tahun = left('".$date_end."',4) and z.id = ".$unit."
                GROUP BY y.id_link
            )Y
            ON x.id_link = y.id_link"
        );
        // return $target_pengguna_jasa;
        $target_income = DB::connection("mysql3")->select("
            SELECT x.id_link, x.target AS target_mountly, y.target AS target_yearly FROM
            (
                SELECT y.id_link, SUM(x.target) AS target 
                FROM new_master_target_income x
                left OUTER JOIN new_master_category Y
                ON x.id_category = y.id
                left outer join  new_master_unit z
                on y.id_unit = z.id
                WHERE (x.thbl between left('".$date_start."',6) and left('".$date_end."',6)) and z.id = ".$unit."
                GROUP BY y.id_link
            )x
            LEFT OUTER JOIN 
            (
                SELECT y.id_link, SUM(x.target) AS target
                FROM new_master_target_income x
                left OUTER JOIN new_master_category Y
                ON x.id_category = y.id
                left outer join  new_master_unit z
                on y.id_unit = z.id
                WHERE x.tahun = left('".$date_end."',4) and z.id = ".$unit."
                GROUP BY y.id_link
            )Y
            ON x.id_link = y.id_link
            group by x.id_link,x.target,y.target
        ");
        $target_income_non = DB::connection("mysql3")->select("
            SELECT x.id_link, x.target AS target_mountly, y.target AS target_yearly FROM
            (
                SELECT y.id_link, x.target 
                FROM new_master_target_income x
                left OUTER JOIN new_master_category Y
                ON x.id_category = y.id
                left outer join  new_master_unit z
                on y.id_unit = z.id
                WHERE (x.thbl between left('".$date_start."',6) and left('".$date_end."',6)) and z.id = ".$unit." and y.id_link = 4
                GROUP BY y.id_link,x.target
            )x
            LEFT OUTER JOIN 
            (
                SELECT y.id_link, SUM(x.target) AS target
                FROM new_master_target_income x
                left OUTER JOIN new_master_category Y
                ON x.id_category = y.id
                left outer join  new_master_unit z
                on y.id_unit = z.id
                WHERE x.tahun = left('".$date_end."',4) and z.id = ".$unit." and y.id_link = 4
                GROUP BY y.id_link,x.target
            )Y
            ON x.id_link = y.id_link
            group by x.id_link,x.target,y.target
        ");

        $count = count($target_pengguna_jasa);

        $data = [
            'ticketing'=>$ticketing,
            'target_pengguna_jasa'=>$target_pengguna_jasa,
            'income'=>$income,
            'target_income'=>$target_income,
            'erp'=>$erp,
            'target_income_non'=>$target_income_non,
            'count'=>$count,
            'unit'=>$unit,
            // 'tanggal'=>$tanggal,
            'detail_pj_dom'=>$detail_pj_dom,
            'detail_pj_asg'=>$detail_pj_asg,
            'detail_pj_pkt'=>$detail_pj_pkt,
            'detail_in_dom'=>$detail_in_dom,
            'detail_in_asg'=>$detail_in_asg,
            'detail_in_pkt'=>$detail_in_pkt,
            'detail_in_not'=>$detail_in_not,
            'tgl_start'=>$tgl_start,
            'tgl_end'=>$tgl_end
        ];
        // return $tanggal;
        return view("report_page",$data);
    }
    public function naikcandi($tgl_start,$tgl_end)
    {
        if(date("Y",strtotime($tgl_start)) != date("Y",strtotime($tgl_end))){
            return redirect()->back()->with("gagal","tahun");
        }
        $hari_start = date("d",strtotime($tgl_start));
        $hari_end = date("d",strtotime($tgl_end));
        $bulan_start = date("m",strtotime($tgl_start));
        $bulan_end = date("m",strtotime($tgl_end));
        $tbl_start = date("Y-m",strtotime($tgl_start));
        $tbl_end = date("Y-m",strtotime($tgl_end));

        $endpoint1 = "https://newapi.goersapp.com/v3.1/integration/auth/token";
        $client1 = new \GuzzleHttp\Client();
        $email = "api.borobudur@goersapp.com";
        $password = "72bedc3e081bb7698a0ed47ea06e1f05ce0ca0f9";
    
        $response1 = $client1->request('POST', $endpoint1,array(
            'form_params' => array(
                'email' => $email,
                'password' => $password
            ),
            'headers' => array(
                'Api-Key' => '013a4392-14c8-438d-bcbc-535be9141d13',
                'G-Channel' => '4'
            )
        ));
    
        $statusCode = $response1->getStatusCode();
        $content = $response1->getBody();

        $token = json_decode($content)->data->token;
        // versi date
        $client = new \GuzzleHttp\Client();

        $startDate = new DateTime($tgl_start);
        $endDate = new DateTime($tgl_end);
        
        $daterange = [];
        
        for ($date = $startDate; $date <= $endDate; $date->modify('+1 day')) {
            $dateString = $date->format('Y-m-d');
            if (!in_array($dateString, $daterange)) {
                $daterange[] = $dateString;
            }
        }
        $length_range = count($daterange);
        $naik_candi = 0;
        $price_naik_candi = 0;
        $array_master = [];
        for ($i=0; $i < $length_range; $i++) {
            $endpoint = "https://newapi.goersapp.com/v3.1/integration/attendees/content?content_id=336606369&content_type=v&start=".$daterange[$i]." 00:00:00&end=".$daterange[$i]." 23:59:59&fields=ticket_price";
            $response = $client->request('GET', $endpoint,array(
                'headers' => array(
                    'Api-Key' => '013a4392-14c8-438d-bcbc-535be9141d13',
                    'G-Channel' => '4',
                    'Authorization' => $token
                )
            ));
            $statusCode = $response->getStatusCode();
            $content = $response->getBody();
            $value = json_decode($content,true)['data'];
            $result = json_encode($value);
            // return $content["data"];
            $naik_candi = $naik_candi + count(json_decode($content)->data);
            // return json_decode($content)->data[];
            for($j=0; $j < count(json_decode($content)->data) ; $j++){
                $ticket_price = json_decode($content)->data[$j]->ticket_price;
                $price_naik_candi = $price_naik_candi + $ticket_price;
            }
            // if($naik_candi > 1200){
            // $naik_candi = 1200;
            // }
        }
        return $price_naik_candi;
        // versi month
        $naik_candi_mtd = 0;
        $tgt_naik_candi_m = 0;

        $dateStart = $tgl_start;
        $dateEnd = $tgl_end;
        
        $monthStart = date('m', strtotime($dateStart));
        $yearStart = date('Y', strtotime($dateStart));
        
        $monthEnd = date('m', strtotime($dateEnd));
        $yearEnd = date('Y', strtotime($dateEnd));
        
        $startDate = new DateTime("$yearStart-$monthStart-01");
        $endDate = new DateTime("$yearEnd-$monthEnd-".date('t', strtotime("$yearEnd-$monthEnd-01")));
        
        for ($date = $startDate; $date <= $endDate; $date->modify('+1 day')) {
            // echo $date->format('Y-m-d') . "<br>";
            $daterange[] = $date->format('Y-m-d');
        }
        $count_last_date = count($daterange);
        for ($i=1; $i < $count_last_date; $i++) {
            $endpoint = "https://newapi.goersapp.com/v3.1/integration/attendees/content?content_id=336606369&content_type=v&start=".$daterange[$i]." 00:00:00&end=".$daterange[$i]." 23:59:59";
            $response = $client->request('GET', $endpoint,array(
                'headers' => array(
                    'Api-Key' => '013a4392-14c8-438d-bcbc-535be9141d13',
                    'G-Channel' => '4',
                    'Authorization' => $token
                )
            ));
            $statusCode = $response->getStatusCode();
            $content = $response->getBody();
            $naik_candi_mtd = $naik_candi_mtd + count(json_decode($content)->data);
            // target month
            $tgt_naik_candi_m = $tgt_naik_candi_m + 1200;
            // target month
        }
        // return $naik_candi;
        // return $tgt_naik_candi_m;
    }
    public function tmii()
    {
        $endpoint = "https://newapi.goersapp.com/v3.1/integration/auth/token";
        $client = new \GuzzleHttp\Client();
        $email = "api.tmii@goersapp.com";
        $password = "72bedc3e081bb7698a0ed47ea06e1f05ce0ca0f9";

        $response = $client->request('POST', $endpoint,array(
            'form_params' => array(
                'email' => $email,
                'password' => $password
            ),
            'headers' => array(
                'Api-Key' => '013a4392-14c8-438d-bcbc-535be9141d13',
                'G-Channel' => '4'
            )
        ));

        $statusCode = $response->getStatusCode();
        $content = $response->getBody();

        $token = json_decode($content)->data->token;

        $endpoint = "https://newapi.goersapp.com/v3.1/integration/attendees/content?content_id=1141225040&content_type=v&start=2023-04-23 00:00:00&end=2023-04-23 23:59:59";

        $response = $client->request('GET', $endpoint,array(
            'headers' => array(
                'Api-Key' => '013a4392-14c8-438d-bcbc-535be9141d13',
                'G-Channel' => '4',
                'Authorization' => $token
            )
        ));

        $statusCode = $response->getStatusCode();
        $content = $response->getBody();
        dd(json_decode($content));
        return $content;
    }
    public function cron_naikcandi()
    {
        $now = Carbon::now()->format("Y-m-d H:i:s");
        $last_row = DB::connection("mysql4")->select("
        select MAX(created_at) as max from trx_test
        ");
        if($last_row[0]->max == null){
            $time = '2000-01-01 00:00:00';
        }else{
            $time = $last_row[0]->max;
        }
        $last_date = date('Y-m-d H:i:s', strtotime($time. ' +1 seconds'));
        // return $last_date;
        $endpoint1 = "https://newapi.goersapp.com/v3.1/integration/auth/token";
        $client1 = new \GuzzleHttp\Client();
        $email = "api.borobudur@goersapp.com";
        $password = "72bedc3e081bb7698a0ed47ea06e1f05ce0ca0f9";
    
        $response1 = $client1->request('POST', $endpoint1,array(
            'form_params' => array(
                'email' => $email,
                'password' => $password
            ),
            'headers' => array(
                'Api-Key' => '013a4392-14c8-438d-bcbc-535be9141d13',
                'G-Channel' => '4'
            )
        ));
        $statusCode = $response1->getStatusCode();
        $content = $response1->getBody();
        $token = json_decode($content)->data->token;
        $client = new \GuzzleHttp\Client();
        $endpoint = "https://newapi.goersapp.com/v3.1/integration/attendees/content?content_id=336606369&content_type=v&start=".$last_date."&end=".$now."&fields=ticket_price";
        $response = $client->request('GET', $endpoint,array(
            'headers' => array(
                'Api-Key' => '013a4392-14c8-438d-bcbc-535be9141d13',
                'G-Channel' => '4',
                'Authorization' => $token
            )
        ));
        $statusCode = $response->getStatusCode();
        $json_raw = $response->getBody();
        $json_raw = json_decode($json_raw,true);
        // return $json_raw;
        $count = count($json_raw['data']);
        // return $count;
        $null = null;
        if($json_raw != null){
            for($i=0;$i<$count;$i++){
                if($i < 300){
                    $cek = sizeof($json_raw['data'][$i]);
                    if($cek == 12){
                        DB::connection("mysql4")->table('trx_test')->insert([
                            'first_name' => $json_raw['data'][$i]['first_name'],
                            'last_name' => $json_raw['data'][$i]['last_name'],
                            'email' => $json_raw['data'][$i]['email'],
                            'phone' => $json_raw['data'][$i]['phone'],
                            'schedule' => $json_raw['data'][$i]['schedule'],
                            'id' => $json_raw['data'][$i]['id'],
                            'ticket_id' => $json_raw['data'][$i]['ticket_id'],
                            'ticket_name' => $json_raw['data'][$i]['ticket_name'],
                            'venue_name' => $json_raw['data'][$i]['venue_name'],
                            'ticket_price' => $json_raw['data'][$i]['ticket_price'],
                            'validated_at' => $json_raw['data'][$i]['validated_at'],
                            'created_at' => $json_raw['data'][$i]['created_at'],
                            'recap_date' => $now,
                        ]);
                    }if($cek == 11){
                        DB::connection("mysql4")->table('trx_test')->insert([
                            'first_name' => $json_raw['data'][$i]['first_name'],
                            'last_name' => $json_raw['data'][$i]['last_name'],
                            'email' => $json_raw['data'][$i]['email'],
                            'phone' => $json_raw['data'][$i]['phone'],
                            'schedule' => $json_raw['data'][$i]['schedule'],
                            'id' => $json_raw['data'][$i]['id'],
                            'ticket_id' => $json_raw['data'][$i]['ticket_id'],
                            'ticket_name' => $json_raw['data'][$i]['ticket_name'],
                            'venue_name' => $json_raw['data'][$i]['venue_name'],
                            'ticket_price' => $json_raw['data'][$i]['ticket_price'],
                            'validated_at' => $null,
                            'created_at' => $json_raw['data'][$i]['created_at'],
                            'recap_date' => $now,
                        ]);
                    }
                }
            }
        }
    }
    public function insertjson()
    {
        $now = Carbon::now()->format("Y-m-d H:i:s");
        $json_file = file_get_contents("apigoers.json");
        $json_raw = json_decode($json_file, JSON_OBJECT_AS_ARRAY);

        $tot_insert = 0;
        $count = count($json_raw['data']);

        $null = null;

        for($i=0;$i<$count;$i++){
            $cek = sizeof($json_raw['data'][$i]);
            if($cek == 12){
                DB::connection("mysql4")->table('trx_test')->insert([
                    'first_name' => $json_raw['data'][$i]['first_name'],
                    'last_name' => $json_raw['data'][$i]['last_name'],
                    'email' => $json_raw['data'][$i]['email'],
                    'phone' => $json_raw['data'][$i]['phone'],
                    'schedule' => $json_raw['data'][$i]['schedule'],
                    'id' => $json_raw['data'][$i]['id'],
                    'ticket_id' => $json_raw['data'][$i]['ticket_id'],
                    'ticket_name' => $json_raw['data'][$i]['ticket_name'],
                    'venue_name' => $json_raw['data'][$i]['venue_name'],
                    'ticket_price' => $json_raw['data'][$i]['ticket_price'],
                    'validated_at' => $json_raw['data'][$i]['validated_at'],
                    'created_at' => $json_raw['data'][$i]['created_at'],
                    'recap_date' => $now,
                ]);
                $tot_insert++;
            }if($cek == 11){
                DB::connection("mysql4")->table('trx_test')->insert([
                    'first_name' => $json_raw['data'][$i]['first_name'],
                    'last_name' => $json_raw['data'][$i]['last_name'],
                    'email' => $json_raw['data'][$i]['email'],
                    'phone' => $json_raw['data'][$i]['phone'],
                    'schedule' => $json_raw['data'][$i]['schedule'],
                    'id' => $json_raw['data'][$i]['id'],
                    'ticket_id' => $json_raw['data'][$i]['ticket_id'],
                    'ticket_name' => $json_raw['data'][$i]['ticket_name'],
                    'venue_name' => $json_raw['data'][$i]['venue_name'],
                    'ticket_price' => $json_raw['data'][$i]['ticket_price'],
                    'validated_at' => $null,
                    'created_at' => $json_raw['data'][$i]['created_at'],
                    'recap_date' => $now,
                ]);
                $tot_insert++;
            }
        }
        if($count == $tot_insert){
            return "SUKSES";
        }else{
            return "KURANG";
        }
    }
    public function cron_tmii()
    {
        $now = Carbon::now()->format("Y-m-d H:i:s");
        $last_row = DB::connection("mysql4")->select("
        select MAX(created_at) as max from tmii_goers
        ");
        if($last_row[0]->max == null){
            $time = '2000-01-01 00:00:00';
        }else{
            $time = $last_row[0]->max;
        }
        $last_date = date('Y-m-d H:i:s', strtotime($time. ' +1 seconds'));
        $endpoint1 = "https://newapi.goersapp.com/v3.1/integration/auth/token";
        $client1 = new \GuzzleHttp\Client();
        $email = "api.tmii@goersapp.com";
        $password = "72bedc3e081bb7698a0ed47ea06e1f05ce0ca0f9";
        $response1 = $client1->request('POST', $endpoint1,array(
            'form_params' => array(
                'email' => $email,
                'password' => $password
            ),
            'headers' => array(
                'Api-Key' => '013a4392-14c8-438d-bcbc-535be9141d13',
                'G-Channel' => '4'
            )
        ));
        $statusCode = $response1->getStatusCode();
        $content = $response1->getBody();
        $token = json_decode($content)->data->token;
        $client = new \GuzzleHttp\Client();
        $endpoint = "https://newapi.goersapp.com/v3.1/integration/attendees/content?content_id=1141225040&content_type=v&start=".$last_date."&end=".$now."&fields=ticket_price";
        $response = $client->request('GET', $endpoint,array(
            'headers' => array(
                'Api-Key' => '013a4392-14c8-438d-bcbc-535be9141d13',
                'G-Channel' => '4',
                'Authorization' => $token
            )
        ));
        $statusCode = $response->getStatusCode();
        $json_raw = $response->getBody();
        $json_raw = json_decode($json_raw,true);
        $count = count($json_raw['data']);
        $null = null;
        if($json_raw != null){
            for($i=0;$i<$count;$i++){
                if($i < 500){
                    $cek = sizeof($json_raw['data'][$i]);
                    if($cek == 12){
                        DB::connection("mysql4")->table('tmii_goers')->insert([
                            'first_name' => $json_raw['data'][$i]['first_name'],
                            'last_name' => $json_raw['data'][$i]['last_name'],
                            'email' => $json_raw['data'][$i]['email'],
                            'phone' => $json_raw['data'][$i]['phone'],
                            'schedule' => $json_raw['data'][$i]['schedule'],
                            'id' => $json_raw['data'][$i]['id'],
                            'ticket_id' => $json_raw['data'][$i]['ticket_id'],
                            'ticket_name' => $json_raw['data'][$i]['ticket_name'],
                            'venue_name' => $json_raw['data'][$i]['venue_name'],
                            'ticket_price' => $json_raw['data'][$i]['ticket_price'],
                            'validated_at' => $json_raw['data'][$i]['validated_at'],
                            'created_at' => $json_raw['data'][$i]['created_at'],
                            'recap_date' => $now,
                        ]);
                    }if($cek == 11){
                        DB::connection("mysql4")->table('tmii_goers')->insert([
                            'first_name' => $json_raw['data'][$i]['first_name'],
                            'last_name' => $json_raw['data'][$i]['last_name'],
                            'email' => $json_raw['data'][$i]['email'],
                            'phone' => $json_raw['data'][$i]['phone'],
                            'schedule' => $json_raw['data'][$i]['schedule'],
                            'id' => $json_raw['data'][$i]['id'],
                            'ticket_id' => $json_raw['data'][$i]['ticket_id'],
                            'ticket_name' => $json_raw['data'][$i]['ticket_name'],
                            'venue_name' => $json_raw['data'][$i]['venue_name'],
                            'ticket_price' => $json_raw['data'][$i]['ticket_price'],
                            'validated_at' => $null,
                            'created_at' => $json_raw['data'][$i]['created_at'],
                            'recap_date' => $now,
                        ]);
                    }
                }
            }
        }
    }
    public function cek()
    {
        $now = Carbon::now()->format("Y-m-d H:i:s");
        $json_file = file_get_contents("cek.json");
        $json_raw = json_decode($json_file, JSON_OBJECT_AS_ARRAY);
        $cek_data = 0;
        $count = count($json_raw['data']);
        $total_check = 0;
        $tot_insert = 0;
        $null = null;
        
        for($i=0;$i<$count;$i++){
            $id = $json_raw['data'][$i]['id'];
            $query_check_id = DB::connection("mysql4")->select("select count(*) as count from trx where id = '".$id."'");
            $qty = $query_check_id[0]->count;
            if($qty == 0){
                $cek = sizeof($json_raw['data'][$i]);
                if($cek == 12){
                    DB::connection("mysql4")->table('trx')->insert([
                        'first_name' => $json_raw['data'][$i]['first_name'],
                        'last_name' => $json_raw['data'][$i]['last_name'],
                        'email' => $json_raw['data'][$i]['email'],
                        'phone' => $json_raw['data'][$i]['phone'],
                        'schedule' => $json_raw['data'][$i]['schedule'],
                        'id' => $json_raw['data'][$i]['id'],
                        'ticket_id' => $json_raw['data'][$i]['ticket_id'],
                        'ticket_name' => $json_raw['data'][$i]['ticket_name'],
                        'venue_name' => $json_raw['data'][$i]['venue_name'],
                        'ticket_price' => $json_raw['data'][$i]['ticket_price'],
                        'validated_at' => $json_raw['data'][$i]['validated_at'],
                        'created_at' => $json_raw['data'][$i]['created_at'],
                        'recap_date' => $now,
                    ]);
                    $tot_insert++;
                }if($cek == 11){
                    DB::connection("mysql4")->table('trx')->insert([
                        'first_name' => $json_raw['data'][$i]['first_name'],
                        'last_name' => $json_raw['data'][$i]['last_name'],
                        'email' => $json_raw['data'][$i]['email'],
                        'phone' => $json_raw['data'][$i]['phone'],
                        'schedule' => $json_raw['data'][$i]['schedule'],
                        'id' => $json_raw['data'][$i]['id'],
                        'ticket_id' => $json_raw['data'][$i]['ticket_id'],
                        'ticket_name' => $json_raw['data'][$i]['ticket_name'],
                        'venue_name' => $json_raw['data'][$i]['venue_name'],
                        'ticket_price' => $json_raw['data'][$i]['ticket_price'],
                        'validated_at' => $null,
                        'created_at' => $json_raw['data'][$i]['created_at'],
                        'recap_date' => $now,
                    ]);
                    $tot_insert++;
                }
            }
            else{
                $total_check++;
            }
        }
        echo "Total Insert : ".$tot_insert.", Total Exist : ".$total_check;
    }
}
